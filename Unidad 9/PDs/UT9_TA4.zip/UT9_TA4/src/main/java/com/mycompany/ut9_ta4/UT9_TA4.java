package com.mycompany.ut9_ta4;

import static com.mycompany.ut9_ta4.TClasificador.METODO_CLASIFICACION_QUICKSORT;
import static com.mycompany.ut9_ta4.TClasificador.METODO_CLASIFICACION_INSERCION;
import static com.mycompany.ut9_ta4.TClasificador.METODO_CLASIFICACION_SHELL;
import static com.mycompany.ut9_ta4.TClasificador.METODO_CLASIFICACION_BURBUJA;
import java.util.Arrays;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */



/**
 *
 * @author TomasUcu
 */
public class UT9_TA4 {

    public static void main(String[] args) {
        GeneradorDatosGenericos generador = new GeneradorDatosGenericos();
        TClasificador clasificador = new TClasificador();
        
        int[] vectorDatosAleatorios = generador.generarDatosAleatorios();
        int[] vectorDatosAscendentes = generador.generarDatosAscendentes();
        int[] vectorDatosDescendentes = generador.generarDatosDescendentes();
        
        clasificador.clasificar(vectorDatosAleatorios, METODO_CLASIFICACION_QUICKSORT);
        clasificador.clasificar(vectorDatosAscendentes, METODO_CLASIFICACION_QUICKSORT);
        clasificador.clasificar(vectorDatosDescendentes, METODO_CLASIFICACION_QUICKSORT);
        
        System.out.println(Arrays.toString(vectorDatosAleatorios));
        System.out.println(Arrays.toString(vectorDatosAscendentes));
        System.out.println(Arrays.toString(vectorDatosDescendentes));
        
        
        vectorDatosAleatorios = generador.generarDatosAleatorios();
        vectorDatosAscendentes = generador.generarDatosAscendentes();
        vectorDatosDescendentes = generador.generarDatosDescendentes();
        
        clasificador.clasificar(vectorDatosAleatorios, METODO_CLASIFICACION_INSERCION);
        clasificador.clasificar(vectorDatosAscendentes, METODO_CLASIFICACION_INSERCION);
        clasificador.clasificar(vectorDatosDescendentes, METODO_CLASIFICACION_INSERCION);
        
        System.out.println(Arrays.toString(vectorDatosAleatorios));
        System.out.println(Arrays.toString(vectorDatosAscendentes));
        System.out.println(Arrays.toString(vectorDatosDescendentes));
        
        
        vectorDatosAleatorios = generador.generarDatosAleatorios();
        vectorDatosAscendentes = generador.generarDatosAscendentes();
        vectorDatosDescendentes = generador.generarDatosDescendentes();
        
        clasificador.clasificar(vectorDatosAleatorios, METODO_CLASIFICACION_SHELL);
        clasificador.clasificar(vectorDatosAscendentes, METODO_CLASIFICACION_SHELL);
        clasificador.clasificar(vectorDatosDescendentes, METODO_CLASIFICACION_SHELL);
        
        System.out.println(Arrays.toString(vectorDatosAleatorios));
        System.out.println(Arrays.toString(vectorDatosAscendentes));
        System.out.println(Arrays.toString(vectorDatosDescendentes));
        
        vectorDatosAleatorios = generador.generarDatosAleatorios();
        vectorDatosAscendentes = generador.generarDatosAscendentes();
        vectorDatosDescendentes = generador.generarDatosDescendentes();
        
        clasificador.clasificar(vectorDatosAleatorios, METODO_CLASIFICACION_BURBUJA);
        clasificador.clasificar(vectorDatosAscendentes, METODO_CLASIFICACION_BURBUJA);
        clasificador.clasificar(vectorDatosDescendentes, METODO_CLASIFICACION_BURBUJA);
        
        System.out.println(Arrays.toString(vectorDatosAleatorios));
        System.out.println(Arrays.toString(vectorDatosAscendentes));
        System.out.println(Arrays.toString(vectorDatosDescendentes));
    }
}
