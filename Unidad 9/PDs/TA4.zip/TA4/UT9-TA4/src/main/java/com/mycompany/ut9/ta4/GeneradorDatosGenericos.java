package com.mycompany.ut9.ta4;

import java.util.Random;

public class GeneradorDatosGenericos {

    public static final int TIPO_ORDEN_ASCENDENTE = 1;
    public static final int TIPO_ORDEN_DESCENDENTE = 2;
    public static final int TIPO_ORDEN_ALEATORIO = 3;

    public int[] generarDatos(int tamaño, int tipoOrden) {
        switch (tipoOrden) {
            case TIPO_ORDEN_ASCENDENTE:
                return generarDatosAscendentesTamaño(tamaño);
            case TIPO_ORDEN_DESCENDENTE:
                return generarDatosDescendentesTamaño(tamaño);
            case TIPO_ORDEN_ALEATORIO:
                return generarDatosAleatoriosTamaño(tamaño);
            default:
                System.err.println("Este codigo no deberia haberse ejecutado");
                break;
        }
        return null ;
    }

    public int[] generarDatosAleatoriosTamaño(int tamaño) {
        Random rnd = new Random();
        int[] datosGenerados = new int[tamaño];
        boolean[] datosUtilizados = new boolean[tamaño];
        for (int i = 0; i < datosGenerados.length; i++) {
            int j = rnd.nextInt(tamaño);
            while (datosUtilizados[j]) {
                j = (j + 1) % tamaño;
            }
            datosGenerados[j] = i;
            datosUtilizados[j] = true;
        }
        return datosGenerados;
    }
    private static int TAMANIO_MAX = 32000;

    public int[] generarDatosAleatorios() {
        Random rnd = new Random();
        int[] datosGenerados = new int[TAMANIO_MAX];
        boolean[] datosUtilizados = new boolean[TAMANIO_MAX];
        for (int i = 0; i < datosGenerados.length; i++) {
            int j = rnd.nextInt(TAMANIO_MAX);
            while (datosUtilizados[j]) {
                j = (j + 1) % TAMANIO_MAX;
            }
            datosGenerados[j] = i;
            datosUtilizados[j] = true;
        }
        return datosGenerados;
    }
    
    public int[] generarDatosAscendentesTamaño(int tamaño) {
        int[] copiaAscendente = new int[tamaño];
        for (int i = 0; i < tamaño; i++) {
            copiaAscendente[i] = i;
        }
        return copiaAscendente;
    }

    public int[] generarDatosAscendentes() {
        int[] copiaAscendente = new int[TAMANIO_MAX];
        for (int i = 0; i < TAMANIO_MAX; i++) {
            copiaAscendente[i] = i;
        }
        return copiaAscendente;
    }
    
    public int[] generarDatosDescendentesTamaño(int tamaño) {
        int[] copiaDescendente = new int[tamaño];
        for (int i = 0; i < tamaño; i++) {
            copiaDescendente[i] = tamaño - i;
        }
        return copiaDescendente;
    }

    public int[] generarDatosDescendentes() {
        int[] copiaDescendente = new int[TAMANIO_MAX];
        for (int i = 0; i < TAMANIO_MAX; i++) {
            copiaDescendente[i] = TAMANIO_MAX - i;
        }
        return copiaDescendente;
    }

}
