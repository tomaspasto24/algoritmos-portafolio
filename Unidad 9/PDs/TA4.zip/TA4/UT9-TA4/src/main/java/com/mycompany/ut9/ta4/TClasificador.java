package com.mycompany.ut9.ta4;

import java.util.Random;

public class TClasificador {

    public static final int METODO_CLASIFICACION_INSERCION = 1;
    public static final int METODO_CLASIFICACION_SHELL = 2;
    public static final int METODO_CLASIFICACION_BURBUJA = 3;
    public static final int METODO_CLASIFICACION_QUICKSORT = 4;
    public static final int METODO_CLASIFICACION_HEAPSORT = 5;


    /**
     * Punto de entrada al clasificador
     *
     * @param metodoClasificacion
     * @param orden
     * @param tamanioVector
     * @return Un vector del tam. solicitado, ordenado por el algoritmo
     * solicitado
     */
    public int[] clasificar(int[] datosParaClasificar, int metodoClasificacion, boolean flag) {
        if (!flag) {
            return datosParaClasificar;
        }
        switch (metodoClasificacion) {
            case METODO_CLASIFICACION_INSERCION:
                return ordenarPorInsercion(datosParaClasificar);
            case METODO_CLASIFICACION_SHELL:
                return ordenarPorShell(datosParaClasificar);
            case METODO_CLASIFICACION_BURBUJA:
                return ordenarPorBurbuja(datosParaClasificar);
            case METODO_CLASIFICACION_QUICKSORT:
                return ordenarPorQuickSort(datosParaClasificar);
            case METODO_CLASIFICACION_HEAPSORT:
                return ordenarPorHeapSort(datosParaClasificar);
            default:
                System.err.println("Este codigo no deberia haberse ejecutado");
                break;
        }
        return datosParaClasificar;
    }


    private void intercambiar(int[] vector, int pos1, int pos2) {
        int temp = vector[pos2];
        vector[pos2] = vector[pos1];
        vector[pos1] = temp;
    }
 
    public boolean estaOrdenado(int[] datosClasificados){
        for (int i = 0; i < datosClasificados.length - 1; i++) {
            if (datosClasificados[i] > datosClasificados[i + 1]){
                return false;
            }
        }
        return true;
    }
    
    public long obtenerTiempoDeEjecucion(int[] arreglo, int metodoDeClasificacion){
        long t1 = System.nanoTime();
        long total = 0;
        int cantLlamadas = 0;
        long tiempoResolucion = 1000000000; // 1 segundo, en nanosegundos

        while (total < tiempoResolucion) {
            cantLlamadas++;
            int[] datosCopia = arreglo.clone();
            this.clasificar(datosCopia, metodoDeClasificacion, true);
            long t2 = System.nanoTime();
            total = t2 - t1;
        }
        
        long tiempoMedioAlgoritmoBase = total / cantLlamadas;
        
        t1 = System.nanoTime();
        total = 0;
        cantLlamadas = 0;
        while (total < tiempoResolucion) {
            cantLlamadas++;
            int[] datosCopia = arreglo.clone();
            this.clasificar(datosCopia, metodoDeClasificacion, false);
            long t2 = System.nanoTime();
            total = t2 - t1;
        }
        
        long tiempoCascara = total / cantLlamadas;
        
        long tiempoMedioAlgoritmo = tiempoMedioAlgoritmoBase - tiempoCascara;
        
        return tiempoMedioAlgoritmo;
    }

    /**
     * @param datosParaClasificar
     * @return
     */
    private int[] ordenarPorShell(int[] datosParaClasificar) {
        int j, inc;
        int[] incrementos = new int[]{31, 15, 7, 3, 1};

        for (int posIncrementoActual = 0; posIncrementoActual < incrementos.length; posIncrementoActual++) {
            inc = incrementos[posIncrementoActual];
            if (inc < (datosParaClasificar.length / 2)){
                for (int i = inc; i < datosParaClasificar.length; i++) {
                    // aux = datosParaClasificar[i];
                    j = i - inc;
                    while (j >= 0) {
                        if (datosParaClasificar[j] > datosParaClasificar[j + inc]) {
                            intercambiar(datosParaClasificar, j, j + inc);
                        }
                        j = j - inc;
                    }
                    //datosParaClasificar[j + inc] = aux;
                }
            }

        }
        return datosParaClasificar;
    }

    /**
     * @param datosParaClasificar
     * @return
     */
    protected int[] ordenarPorInsercion(int[] datosParaClasificar) {
        if (datosParaClasificar != null) {
            for (int i = 1; i < datosParaClasificar.length; i++) {
                int j = i - 1;
                while ((j >= 0) && (datosParaClasificar[j+1] < datosParaClasificar[j])) {
                    intercambiar(datosParaClasificar, j, j + 1);
                    j--;
                }
            }
            return datosParaClasificar;
        }
        return null;
    }
   
    private int[] ordenarPorBurbuja(int[] datosParaClasificar) {
        int n = datosParaClasificar.length - 1;
        for (int i = 0; i < n; i++) {
            for (int j = n; j >= (i + 1); j--) {
                if (datosParaClasificar[j] < datosParaClasificar[j - 1]) {
                    intercambiar(datosParaClasificar, j - 1, j);
                }
            }
        }
        return datosParaClasificar;
    }
    
    protected int[] ordenarPorQuickSort(int[] datosParaClasificar) {
        int[] prof = {0, 0, 0};
        quicksort(datosParaClasificar, 0, datosParaClasificar.length - 1, prof);
        //System.out.println("La profundidad es " + prof[2]);
        return datosParaClasificar;
    }

    private int encuentraPivoteRandom(int izq, int der, int[] arreglo) {
        int primero = arreglo[izq];
        int indice = izq;
        if (arreglo[indice] != primero) {
            return -1;
        }

        Random rnd = new Random();
        rnd.setSeed(42);
        return rnd.nextInt(izq, der);
    }

    private int encuentraPivote(int izq, int der, int[] arreglo) {
        int primero = arreglo[izq];
        int indice = izq;
        if (arreglo[indice] != primero) {
            return -1;
        }

        int minPos = izq;
        if (arreglo[minPos] < arreglo[(izq + der) / 2]) {
            minPos = (izq + der) / 2;
        }
        if (arreglo[minPos] < arreglo[der]) {
            minPos = der;
        }
        return minPos;
    }

    private void quicksort(int[] entrada, int i, int j, int[] prof) {
        int izquierda = i;
        int derecha = j;
        int posicionPivote = encuentraPivoteRandom(izquierda, derecha, entrada);

        if (posicionPivote >= 0) {
            //int pivote = posicionPivote;
            int pivote = entrada[posicionPivote];
            while (izquierda <= derecha) {
                while ((entrada[izquierda] < pivote) && (izquierda < j)) {
                    //izquierda--;
                    izquierda++;
                }

                while ((pivote <= entrada[derecha]) && (derecha > i)) {
                    //derecha++;
                    derecha--;
                }

                if (izquierda <= derecha) {
                    intercambiar(entrada, derecha, izquierda);
                    izquierda++;
                    derecha--;
                }
            }

            if (i < derecha) {
                //quicksort(entrada, i, izquierda);
                prof[0]++;
                quicksort(entrada, i, derecha, prof);
            }
            if (izquierda < j) {
                //quicksort(entrada, derecha, j);
                prof[1]++;
                quicksort(entrada, izquierda, j, prof);
            }
            prof[2] = Math.max(prof[0], prof[1]) + 1;
        }
    }

    protected int[] ordenarPorHeapSort(int[] datosParaClasificar) {
        for (int i = (datosParaClasificar.length - 1) / 2; i > 0; i--) { //Armo el heap inicial de n-1 div 2 hasta 0
            armaHeap(datosParaClasificar, i, datosParaClasificar.length - 1);
        }
        for (int i = datosParaClasificar.length - 1; i > 1; i--) {
            intercambiar(datosParaClasificar, 1, i);
            armaHeap(datosParaClasificar, 1, i - 1);
        }
        return datosParaClasificar;
    }

    private void armaHeap(int[] datosParaClasificar, int primero, int ultimo) {
        if (primero < ultimo) {
            int r = primero;
            while (r <= ultimo / 2) {
                if (ultimo == 2 * r) { //r tiene un hijo solo
                    if (datosParaClasificar[r] > datosParaClasificar[r * 2]) {
                        intercambiar(datosParaClasificar, r, 2 * r);
                    }
                    r = ultimo;
                } else { //r tiene 2 hijos
                    int posicionIntercambio = 0;
                    if (datosParaClasificar[2 * r] > datosParaClasificar[2 * r + 1]) {
                        posicionIntercambio = 2 * r + 1;
                    } else {
                        posicionIntercambio = 2 * r;
                    }
                    if (datosParaClasificar[r] > datosParaClasificar[posicionIntercambio]) {
                        intercambiar(datosParaClasificar, r, posicionIntercambio);
                        r = posicionIntercambio;
                    } else {
                        r = ultimo;
                    }
                }
            }
        }
    }

}
