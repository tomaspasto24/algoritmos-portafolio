/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.ut9.ta4;

import java.lang.*;

/**
 *
 * @author juan-
 */
public class UT9TA4 {

    public static void main(String[] args) {
        TClasificador clasif = new TClasificador();
        GeneradorDatosGenericos gdg = new GeneradorDatosGenericos();

        int[] vectorAscendente300 = gdg.generarDatos(300, 1);
        int[] vectorDescendente300 = gdg.generarDatos(300, 2);
        int[] vectorAleatorio300 = gdg.generarDatos(300, 3);
        
        System.out.println("Inserción Directa 300 - Ascendente\n" + clasif.obtenerTiempoDeEjecucion(vectorAscendente300, 4) + " ns");
        System.out.println("Inserción Directa 300 - Descendente\n" + clasif.obtenerTiempoDeEjecucion(vectorDescendente300,4) + " ns");
        System.out.println("Inserción Directa 300 - Aleatorio\n" + clasif.obtenerTiempoDeEjecucion(vectorAleatorio300, 4) + " ns");
        
        /*
        int[] vectorAscendente10000 = gdg.generarDatos(10000, 1);
        int[] vectorDescendente10000 = gdg.generarDatos(10000, 2);
        int[] vectorAleatorio10000 = gdg.generarDatos(10000, 3);
        
        System.out.println("Inserción Directa 10000 - Ascendente\n" + clasif.obtenerTiempoDeEjecucion(vectorAscendente10000, 4) + " ns");
        System.out.println("Inserción Directa 10000 - Descendente\n" + clasif.obtenerTiempoDeEjecucion(vectorDescendente10000, 4) + " ns");
        System.out.println("Inserción Directa 300 - Aleatorio\n" + clasif.obtenerTiempoDeEjecucion(vectorAleatorio10000, 4) + " ns");
        */
    /*
        int[] vectorAscendente30000 = gdg.generarDatos(30000, 1);
        int[] vectorDescendente30000 = gdg.generarDatos(30000, 2);
        int[] vectorAleatorio30000 = gdg.generarDatos(30000, 3);
        
        System.out.println("Inserción Directa 30000 - Ascendente\n" + clasif.obtenerTiempoDeEjecucion(vectorAscendente30000, 5) + " ns");
        System.out.println("Inserción Directa 30000 - Descendente\n" + clasif.obtenerTiempoDeEjecucion(vectorDescendente30000, 5) + " ns");
        System.out.println("Inserción Directa 30000 - Aleatorio\n" + clasif.obtenerTiempoDeEjecucion(vectorAleatorio30000, 5) + " ns"); */
    }
}
