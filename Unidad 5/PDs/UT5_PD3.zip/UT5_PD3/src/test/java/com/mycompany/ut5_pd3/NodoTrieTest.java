/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.ut5_pd3;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author TomasUcu
 */
public class NodoTrieTest {
    
    public NodoTrieTest() {
    }

    @Test
    public void testBuscar() {
        ArbolTrie trie = new ArbolTrie();
       ILista<Integer> lista = new Lista<>();
       lista.insertar(new Nodo(22, 22));
       lista.insertar(new Nodo(10, 10));
        
        trie.insertar("hola", 2);
        trie.insertar("helado", 10);
        trie.insertar("elefante", 1);
        trie.insertar("vehiculo", 2);
        trie.insertar("velocimetro", 3);

        assertEquals(trie.buscar("hola").getPaginas().retornarPrimero().getDato(), 2);
        assertEquals(trie.buscar("Helado").getPaginas().retornarPrimero().getDato(), 10);
        assertEquals(trie.buscar("velocimetro").getPaginas().retornarPrimero().getDato(), 3);
    }

    @Test
    public void testIndizarLibro() {
        ArbolTrie trie = new ArbolTrie();
        trie.indizarLibro("src/main/java/com/mycompany/ut5_pd3/loremIpsum.txt");

        assertNotNull(trie.buscar("amet"));
        assertNotNull(trie.buscar("gravida"));
        assertNotNull(trie.buscar("viverra"));
        assertNotNull(trie.buscar("Aenean"));
    }


    @Test
    public void testIndizarLibroPaginas() {
        ArbolTrie trie = new ArbolTrie();
        trie.indizarLibro("src/main/java/com/mycompany/ut5_pd3/palabras1.txt");
        
        assertEquals(trie.buscar("boxer").getPaginas().imprimir(), "1, ");
        assertNotNull(trie.buscar("boxer"));
    }

    @Test
    public void testImprimirIndice() {
        ArbolTrie trie = new ArbolTrie();
        trie.indizarLibro("src/main/java/com/mycompany/ut5_pd3/palabras1.txt");
        
        trie.imprimirIndice();
    }
}
