package com.mycompany.ut5_pd3;

import java.util.LinkedList;


public class ArbolTrie implements IArbolTrie {

    private NodoTrie raiz;

    @Override
    public void insertar(String palabra, Integer paginas) {
        if (raiz == null) {
            raiz = new NodoTrie();
        }
        raiz.insertar(palabra, paginas);
    }

    @Override
    public void imprimir() {
        if (raiz != null) {
            raiz.imprimir();
        }
    }

    public void imprimirIndice() {
        if (raiz != null) {
            raiz.imprimirIndice();
        }
    }

    @Override
    public NodoTrie buscar(String palabra) {
        if(raiz != null) {
            return raiz.buscar(palabra);
        }
        return null;
    }

    @Override
    public LinkedList<String> predecir(String prefijo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void indizarLibro(String direccionArchivo) {
        int contPaginas = 1;
        int contLineas = 1;
        String[] lineas = ManejadorArchivosGenerico.leerArchivo(direccionArchivo);
        
        for(String linea : lineas) {
            contLineas++;
            if(contLineas >= 50) {
                contPaginas++;
                contLineas = 1;
            }
            
            String[] palabras = linea.split(" ");
            
            for(String palabra : palabras) {
                this.insertar(palabra, contPaginas);
            }
        }
    }
}
