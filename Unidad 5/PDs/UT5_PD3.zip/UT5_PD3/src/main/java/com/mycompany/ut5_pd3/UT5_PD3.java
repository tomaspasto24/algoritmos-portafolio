/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ut5_pd3;

/**
 *
 * @author TomasUcu
 */
public class UT5_PD3 {

    public static void main(String[] args) {
    }

}