/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.ut5_pd1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author TomasUcu
 */
public class ArbolTest {
    
    public ArbolTest() {
    }

    @Test
    public void testInsertarArbolVacioEtiquetaPadreCualquiera() {
        Arbol<Comparable> arbol = new Arbol<>();
        
        arbol.insertar("Prueba", "PruebaPadre");
        
        assertNull(arbol.raiz);
    }

    @Test
    public void testInsertarArbolVacioEtiquetaPadreVacia() {
        Arbol<Comparable> arbol = new Arbol<>();
        
        arbol.insertar("Prueba", "");
        
        assertEquals(arbol.raiz.getDatos(), "Prueba");
    }  
    
    @Test
    public void testInsertarArbolConElementosEtiquetaPadreNoValida() {
        Arbol<Comparable> arbol = new Arbol<>();
        
        arbol.insertar("Prueba", "");
        
        arbol.insertar("PruebaHijo1", "Prueba");
        arbol.insertar("PruebaHijo2", "Prueba");
        arbol.insertar("PruebaHijo3", "Prueba");
        
        String etiquetaHijo = "hijo 1";
        String etiquetaPadre = "Padre no valido";
        
        arbol.insertar(etiquetaHijo, etiquetaPadre);
        
        assertFalse(arbol.listarIdentado().contains(etiquetaHijo));
        assertFalse(arbol.listarIdentado().contains(etiquetaPadre));
    }  
    
    @Test
    public void testInsertarArbolConElementosEtiquetaPadreCorrecta() {
        Arbol<Comparable> arbol = new Arbol<>();
        
        arbol.insertar("Prueba", "");
        
        arbol.insertar("PruebaHijo1", "Prueba");
        arbol.insertar("PruebaHijo2", "Prueba");
        arbol.insertar("PruebaHijo3", "Prueba");
        
        String etiquetaHijo = "hijo 1";
        String etiquetaPadre = "PruebaHijo3";
        
        arbol.insertar(etiquetaHijo, etiquetaPadre);
        
        assertTrue(arbol.listarIdentado().contains(etiquetaHijo));
        assertTrue(arbol.listarIdentado().contains(etiquetaPadre));
        assertEquals(arbol.raiz.getPrimerHijo().getPrimerHijo().getDatos(), etiquetaHijo);
    }  

    @Test
    public void testBuscarEnArbolVacio() {
        Arbol<Comparable> arbol = new Arbol<>();
        
        NodoArbol<Comparable> nodoEncontrado = arbol.buscar("Test");
        
        assertNull(nodoEncontrado);
    }


    @Test
    public void testBuscarEnArbolElementosEtiquetaInexistente() {
        Arbol<Comparable> arbol = new Arbol<>();
        
        NodoArbol<Comparable> nodo1 = new NodoArbol<>("Test1", "Test1");
        NodoArbol<Comparable> nodo2 = new NodoArbol<>("Test2", "Test2");
        nodo1.setPrimerHijo(nodo2);
        NodoArbol<Comparable> nodo3 = new NodoArbol<>("Test3", "Test3");
        nodo2.setSiguienteHermano(nodo3);
        
        arbol.raiz = nodo1;
        
        NodoArbol<Comparable> nodoEncontrado = arbol.buscar("Test9");
        
        assertNull(nodoEncontrado);
    }

    @Test
    public void testBuscarEnArbolElementosEtiquetaExistente() {
        Arbol<Comparable> arbol = new Arbol<>();
        
        NodoArbol<Comparable> nodo1 = new NodoArbol<>("Test1", "Test1");
        NodoArbol<Comparable> nodo2 = new NodoArbol<>("Test2", "Test2");
        nodo1.setPrimerHijo(nodo2);
        NodoArbol<Comparable> nodo3 = new NodoArbol<>("Test3", "Test3");
        nodo2.setSiguienteHermano(nodo3);
        
        arbol.raiz = nodo1;
        
        NodoArbol<Comparable> nodoEncontrado1 = arbol.buscar("Test3");
        NodoArbol<Comparable> nodoEncontrado2 = arbol.buscar("Test2");
        NodoArbol<Comparable> nodoEncontrado3 = arbol.buscar("Test1");
        
        assertEquals(nodoEncontrado1, nodo2.getSiguienteHermano());
        assertEquals(nodoEncontrado2, nodo1.getPrimerHijo());
        assertEquals(nodoEncontrado3, arbol.raiz);
    }
    
    @Test
    public void testListarIdentadoEnArbolVacio() {
        Arbol<Comparable> arbol = new Arbol<>();
        
        String nodoEncontrado = arbol.listarIdentado();
        
        assertEquals(nodoEncontrado, "");
    }
    
    @Test
    public void testListarIdentadoEnArbolUnElemento() {
        Arbol<Comparable> arbol = new Arbol<>();
        
        arbol.raiz = new NodoArbol<>("Test1", "Test1");
        
        String lista = arbol.listarIdentado();
        
        assertEquals(lista, "Test1"+ "\n");
    }
    
    @Test
    public void testListarIdentadoEnArbolVariosElementos() {
        Arbol<Comparable> arbol = new Arbol<>();
        
        arbol.raiz = new NodoArbol<>("Test1", "Test1");
        
        arbol.insertar("hijoTest1", "Test1");
        arbol.insertar("hijoTest1-1", "Test1");
        arbol.insertar("nietoTest1", "hijoTest1-1");
        arbol.insertar("nietoTest2", "hijoTest1");
        arbol.insertar("bisnietoTest2", "nietoTest1");
        
        String lista = arbol.listarIdentado();
        
        assertTrue(lista.contains("Test1"));
        assertTrue(lista.contains("   hijoTest1"));
        assertTrue(lista.contains("   hijoTest1-1"));
        assertTrue(lista.contains("      nietoTest1"));
        assertTrue(lista.contains("      nietoTest2"));
        assertTrue(lista.contains("         bisnietoTest2"));
    }
}
