/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ut5_pd1;

/**
 *
 * @author TomasUcu
 */
public class Arbol<T> {
    protected NodoArbol<T> raiz;
    
    public Arbol() {
        raiz = null;
    }

    public boolean insertar(Comparable etiquetaHijo, Comparable etiquetaPadre) {
        if(etiquetaPadre.equals("")) {
            NodoArbol<T> nodoInsertar = new NodoArbol(etiquetaHijo, etiquetaHijo);
            
            if(raiz != null) {
                raiz.setSiguienteHermano( (raiz != null) ? raiz.getPrimerHijo() : null );
                raiz.setPrimerHijo(null);
            }
            nodoInsertar.setPrimerHijo(raiz);
            raiz = nodoInsertar;
            return true;
        } else {
            if(raiz != null) {
                return raiz.insertar(etiquetaHijo, etiquetaPadre);
            }
            return false;
        }
    }
    
    public NodoArbol<T> buscar(Comparable etiqueta) {
        if(raiz != null) {
            return raiz.buscar(etiqueta);
        } else {
            return null;
        }
    }
    
    public String listarIdentado() {
        StringBuffer string = new StringBuffer();
        if(raiz != null) {
            raiz.listarIdentado(0, string);
        }
        
        return string.toString();
    }
}
