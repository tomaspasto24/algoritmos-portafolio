/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ut5_pd1;

/**
 *
 * @author TomasUcu
 */
public class NodoArbol<T> {
    private Comparable etiqueta;
    private T datos;
    private NodoArbol<T> primerHijo;
    private NodoArbol<T> siguienteHermano;
    
    public NodoArbol(Comparable etiqueta, T datos) {
        this.etiqueta = etiqueta;
        this.datos = datos;
        this.primerHijo = null;
        this.siguienteHermano = null;
    }
    
    public Comparable getEtiqueta() {
        return this.etiqueta;
    }
    
    public T getDatos() {
        return this.datos;
    }
    
    public NodoArbol<T> getPrimerHijo() {
        return this.primerHijo;
    }

    public NodoArbol<T> getSiguienteHermano() {
        return this.siguienteHermano;
    }

    public void setPrimerHijo(NodoArbol<T> elemento) {
        this.primerHijo = elemento;
    }

    public void setSiguienteHermano(NodoArbol<T> elemento) {
        this.siguienteHermano = elemento;
    }
    
    public boolean insertar(Comparable etiquetaHijo, Comparable etiquetaPadre) {
        if(this.etiqueta.equals(etiquetaPadre)) {
            NodoArbol<T> nodoInsertar = new NodoArbol(etiquetaHijo, etiquetaHijo);
            nodoInsertar.setSiguienteHermano(this.primerHijo);
            this.primerHijo = nodoInsertar;
            return true;
        } else {
            NodoArbol<T> hijo = this.primerHijo;
            boolean res = false;
            while(hijo != null && res == false) {
                res = hijo.insertar(etiquetaHijo, etiquetaPadre);
                if(res == false) {
                    hijo = hijo.siguienteHermano;
                }
            }
            return res;
        }
    }
    
    public NodoArbol<T> buscar(Comparable etiqueta) {
        if(this.etiqueta.equals(etiqueta)) {
            return this;
        } else {
            NodoArbol<T> hijo = this.primerHijo;
            NodoArbol<T> res = null;
            while(hijo != null && res == null) {
                res = hijo.buscar(etiqueta);
                if(res == null) {
                    hijo = hijo.siguienteHermano;
                }
            }
            return res;
        }
    }
    
    public void listarIdentado(int tabulaciones, StringBuffer string) {
        string.append("   ".repeat(tabulaciones) + this.etiqueta + "\n");
        
        if(primerHijo != null) {      
            primerHijo.listarIdentado(tabulaciones + 1, string);
        }
        if(siguienteHermano != null) {
            siguienteHermano.listarIdentado(tabulaciones, string);
        }
    }
}
