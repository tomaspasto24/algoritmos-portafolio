/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ut5_pd7;

/**
 *
 * @author TomasUcu
 */
public class UT5_PD7 {

    public static void main(String[] args) {
//       EL ARCHIVO abonados.txt NO SE ENCUENTRA EN LOS PDS PLANTEADOS DE TODOS
//       MODOS LA FUNCIÓN CREADA QUEDA TESTEADA EN SU RESPECTIVO TEST CASE.    
    }
}
