
package com.mycompany.ut5_pd7;

import java.util.LinkedList;
import java.util.TreeSet;

public class NodoTrie implements INodoTrie {

    private static final int CANT_NUMERICO = 10;
    private NodoTrie[] hijos;
    private boolean esPalabra;
    private Cliente cliente;
    
    public NodoTrie() {
        hijos = new NodoTrie[CANT_NUMERICO];
        esPalabra = false;
    }

    @Override
    public void insertar(String numero, Cliente cliente) {
        numero = comprobar(numero);
        NodoTrie nodo = this;
        char[] numeros = numero.toCharArray();
        for (char c : numeros) {
            int indice = (int)c - '0';
            if (nodo.hijos[indice] == null) {
                nodo.hijos[indice] = new NodoTrie();
            }               
            nodo = nodo.hijos[indice];
        }
        nodo.esPalabra = true;
        nodo.cliente = cliente;
    }

    private void imprimir(String s, NodoTrie nodo) {
        if (nodo != null) {
            if (nodo.esPalabra) {
                System.out.println(s);
                
            }
            for (int c = 0; c < CANT_NUMERICO; c++) {
                if (nodo.hijos[c] != null) {
                    imprimir(s+(char)(c + '0'), nodo.hijos[c]);
                }
            }
        }
    }

    @Override
    public void imprimir() {
        
        imprimir("", this);
    }
    
    private void imprimirIndice(String s, NodoTrie nodo) {
        if (nodo != null) {
            if (nodo.esPalabra) {
                System.out.println(s + " Nombre: " + nodo.getCliente().getNombre());
                
            }
            for (int c = 0; c < CANT_NUMERICO; c++) {
                if (nodo.hijos[c] != null) {
                    imprimirIndice(s+(char)(c + '0'), nodo.hijos[c]);
                }
            }
        }
    }

    public void imprimirIndice() {
        imprimirIndice("", this);
    }
    
      private NodoTrie buscarNodoTrie(String s) {
        NodoTrie nodo = this;
     
         // implementar
        
        return nodo;
    }
    
     private void predecir(String s, String prefijo, LinkedList<String> palabras, NodoTrie nodo) {
     // implementar
       
    }

    @Override
    public void predecir(String prefijo, LinkedList<String> palabras) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public NodoTrie buscar(String s) {
       int comp = 1; //incluyendo a la raíz
       s = s.toLowerCase();
       NodoTrie nodoActual = this;
       char [] partes = s.toCharArray();
       
       for(char m: partes) {
           NodoTrie unHijo = nodoActual.obtenerHijo(m);
           if(unHijo == null) 
           {
               comp++;
               System.out.println("No existe en el indice, cantidad de comparaciones: " + comp);
               return null;               
           } else {
               comp++;
               nodoActual = unHijo;               
           }
       }
       if(nodoActual.esPalabra) {
           comp++;
           System.out.println("Existe la palabra, cantidad de comparaciones: " + comp + " nombre: " + nodoActual.getCliente().getNombre());
           return nodoActual;
       } else {
           comp++;
           return null;
       } 
    }
    
    private NodoTrie obtenerHijo(char m)
    {
        int index = m-'0';
        if( index >= 0 && index <=10)
        {
            return this.hijos[index];
        }
        return null;
    }
    
    public Cliente getCliente() {
        return this.cliente;
    }
    
    public String comprobar(String cadena) {
        cadena = cadena.toLowerCase();
        char[] partes = cadena.toCharArray();
        StringBuilder string = new StringBuilder();
        int cont = 0;
        
        for(char c : partes) {
            int index = c-'0';
            if( index >= 0 && index <=10)
            {
                string.append(c);
            } 
        }
        return string.toString();
    }
    
    public void buscarTelefonos(String codigoPais, String codigoArea, ArbolBB<Cliente> tree) {
        String prefijo = codigoPais + codigoArea;
        NodoTrie aux = buscarNodoTrie(prefijo);
        if(aux != null) {
            aux.predecirAux(prefijo, tree);
        }
    }

    public void predecirAux(String texto, ArbolBB<Cliente> tree) {
        if(this.esPalabra) {
            tree.insertar(new ElementoAB<>(cliente.getNombre(), cliente));
        }
        
        int c = 0;
        while(c < CANT_NUMERICO) {
            if(this.hijos[c] != null) {
                this.hijos[c].predecirAux(texto + (char) (c + '0'), tree);
            }
            c++;
        }
    }
}
