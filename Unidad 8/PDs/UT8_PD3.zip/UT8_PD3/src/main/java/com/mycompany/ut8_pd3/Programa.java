package com.mycompany.ut8_pd3;


import java.util.Collection;
import java.util.LinkedList;
import java.util.StringTokenizer;

public class Programa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      // cargar grafo con casas y distancias
        TGrafoRedElectrica laRed =  (TGrafoRedElectrica) UtilGrafos.cargarGrafo(
                "src/main/java/com/mycompany/ut8_pd3/barrio.txt",
                "src/main/java/com/mycompany/ut8_pd3/distancias.txt",
                false, TGrafoRedElectrica.class);
        
        TAristas ar = laRed.mejorRedElectrica();
        String[] red = new String[ar.size()];
        int c = 0;
        for(TArista a : ar) {
            red[c++] = "A: " + a.etiquetaDestino + " B: " + a.etiquetaOrigen + " Cable: " + a.costo;
        }
        
        ManejadorArchivosGenerico.escribirArchivo("src/main/java/com/mycompany/ut8_pd3/redelectrica.txt", red);
    }
}
