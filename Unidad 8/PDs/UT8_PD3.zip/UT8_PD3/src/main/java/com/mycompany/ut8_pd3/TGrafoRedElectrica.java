package com.mycompany.ut8_pd3;




import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ocamp
 */
public class TGrafoRedElectrica extends TGrafoNoDirigido implements IGrafoRedElectrica{
    
    public TGrafoRedElectrica(Collection<TVertice> vertices, Collection<TArista> aristas) {
        super(vertices, aristas);
    }

    @Override
    public TAristas mejorRedElectrica() {
        TAristas F = new TAristas();
        int numVertices = this.getVertices().size();
        Map<Comparable, Integer> componentes = new HashMap<>();
        int i = 0;
        for (Comparable vertice : this.getVertices().keySet()) {
            componentes.put(vertice, i);
            i++;
        }
        int contador = numVertices - 1;

        Iterator<TArista> iter = aristas.iterator();
        while (contador > 0 && iter.hasNext()) {
            TArista arista = iter.next();
            
            Comparable origen = arista.getEtiquetaOrigen();
            Comparable destino = arista.getEtiquetaDestino();
            
            Integer comp1 = componentes.get(arista.etiquetaOrigen);
            Integer comp2 = componentes.get(arista.etiquetaDestino);
            if (!comp1.equals(comp2)) {
                F.add(arista);
                for (Comparable vertice : this.getVertices().keySet()) {
                    if (componentes.get(vertice).equals(comp1)) {
                        componentes.put(vertice, comp2);
                    }
                }
                contador--;
            }
        }
        if (contador > 0) {
            return null;
        }
        return F;
    }

}