package com.mycompany.ut8_pd3;




import java.util.Collection;
import java.util.Map;

public interface IGrafoRedElectrica {

 
    public TAristas mejorRedElectrica();

    
}
