/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ut3_ta10;

import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author TomasUcu
 */

public class ManejadorSucursales implements IManejadorSucursales {
    
    LinkedList<ISucursal> listaSucursales = new LinkedList<ISucursal>();

    @Override
    public void agregarSucursal(Sucursal sucursal) {
        this.listaSucursales.add(sucursal);
    }

    @Override
    public ISucursal buscarSucursal(String clave) {
        for(ISucursal sucursal : this.listaSucursales) {
            if(sucursal.retornarCiudad().equals(clave)) {
                return sucursal;
            }
        }
        return null;
    }

    @Override
    public boolean quitarSucursal(String clave) {
        for(ISucursal sucursal : this.listaSucursales) {
            if(sucursal.retornarCiudad().equals(clave)) {
                this.listaSucursales.remove(sucursal);
                return true;
            }
        }
        return false;
    }

    @Override
    public String listarSucursales() {
        StringBuilder cadena = new StringBuilder();
        for(ISucursal sucursal : this.listaSucursales) {
                cadena.append(sucursal.retornarCiudad() + " ");
        }
        return cadena.toString();
    }

    @Override
    public int cantSucursales() {
        return this.listaSucursales.size();
    }

    @Override
    public boolean esVacio() {
        return this.listaSucursales.isEmpty();
    }
    
    public void cargarSucursales() {
        String[] lineas = ManejadorArchivosGenerico.leerArchivo("sucursales.txt");
        for(String linea : lineas) {
            this.listaSucursales.add(new Sucursal(linea));
        }
    }
    
}
