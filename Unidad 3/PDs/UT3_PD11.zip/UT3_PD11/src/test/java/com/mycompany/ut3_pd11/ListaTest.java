/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.ut3_pd11;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;

/**
 *
 * @author TomasUcu
 */
public class ListaTest {
    ListaOrdenada<String> lista;

    @Test
    @DisplayName("Test ordena pares e impares")
    public void testOrdenaParesImpares() {
        lista = new ListaOrdenada();
        lista.insertar(new Nodo(4, "Hola"));
        lista.insertar(new Nodo(71, "Hola"));
        lista.insertar(new Nodo(3, "Hola"));
        lista.insertar(new Nodo(6, "Hola"));
        lista.insertar(new Nodo(12, "Hola"));
        lista.insertar(new Nodo(8, "Hola"));
        lista.insertar(new Nodo(35, "Hola"));
        lista.insertar(new Nodo(11, "Hola"));
        lista.insertar(new Nodo(22, "Hola"));
        lista.insertar(new Nodo(17, "Hola"));
        
        assertEquals(lista.ordenaParesImpares().imprimir(), " 3 11 17 35 71 4 6 8 12 22");
    }

    
}
