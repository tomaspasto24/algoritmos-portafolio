/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.ut3_pd11;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author TomasUcu
 */
public class ListaOrdenadaTest {
    
    public ListaOrdenadaTest() {
    }

    @Test
    public void testInsertarOrdenadoDosElementos() {
        Nodo nodo1 = new Nodo(12, "Hola");
        Nodo nodo2 = new Nodo(6, "Hola");
        ListaOrdenada<String> lista = new ListaOrdenada();
        lista.insertarOrdenado(nodo1);
        lista.insertarOrdenado(nodo2);
        
        assertEquals(lista.primero.getEtiqueta(), 6);
        assertEquals(lista.imprimir(), " 6 12");
    }
    
}
