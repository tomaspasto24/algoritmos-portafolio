/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ut3_pd11;

/**
 *
 * @author TomasUcu
 */
public class UT3_PD11 {

    public static void main(String[] args) {
        ListaOrdenada<String> lista = new ListaOrdenada();
        
        lista.insertar(new Nodo(4, "Hola"));
        lista.insertar(new Nodo(71, "Hola"));
        lista.insertar(new Nodo(3, "Hola"));
        lista.insertar(new Nodo(6, "Hola"));
        lista.insertar(new Nodo(12, "Hola"));
        lista.insertar(new Nodo(8, "Hola"));
        lista.insertar(new Nodo(35, "Hola"));
        lista.insertar(new Nodo(11, "Hola"));
        lista.insertar(new Nodo(22, "Hola"));
        lista.insertar(new Nodo(17, "Hola"));
        
        System.out.println(lista.ordenaParesImpares().imprimir());
    }
}
