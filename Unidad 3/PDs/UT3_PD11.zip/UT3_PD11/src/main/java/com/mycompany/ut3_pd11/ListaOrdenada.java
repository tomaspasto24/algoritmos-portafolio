/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ut3_pd11;

/**
 *
 * @author TomasUcu
 */
//Precondición: la etiqueta del nodo tiene que ser Integer.
public class ListaOrdenada<T> extends Lista<T> {
    public boolean insertarOrdenado(Nodo<T> nodo) {
        Nodo<T> nodoInsertar = nodo.clone();
        if(this.primero == null) {
            this.primero = nodoInsertar;
            primero.setSiguiente(null);
            return true;
        } else {
            
            INodo nodoActual = this.primero;            
            if(nodoActual.getEtiqueta().compareTo(nodoInsertar.getEtiqueta()) >= 0) {
                nodoInsertar.setSiguiente((Nodo)this.primero);
                this.primero = nodoInsertar;
                return true;
            }
            
            while(nodoActual.getSiguiente() != null) {
                if(nodoActual.getSiguiente().getEtiqueta().compareTo(nodoInsertar.getEtiqueta()) > 0) {
                    nodoInsertar.setSiguiente(nodoActual.getSiguiente());
                    nodoActual.setSiguiente((Nodo)nodoInsertar);
                    return true;
                }
                nodoActual = nodoActual.getSiguiente();
            }
            nodoInsertar.setSiguiente(null);
            nodoActual.setSiguiente((Nodo)nodoInsertar);
            return true;
        }
    }
}
