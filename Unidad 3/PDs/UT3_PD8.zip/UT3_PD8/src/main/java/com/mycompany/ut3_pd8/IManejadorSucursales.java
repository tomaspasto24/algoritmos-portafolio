/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.ut3_pd8;

/**
 *
 * @author TomasUcu
 */
public interface IManejadorSucursales {
    public void agregarSucursal(Sucursal sucursal);
    public ISucursal buscarSucursal(String clave);
    public boolean quitarSucursal(String clave);
    public String listarSucursales();
    public int cantSucursales();
    public boolean esVacio();
}
