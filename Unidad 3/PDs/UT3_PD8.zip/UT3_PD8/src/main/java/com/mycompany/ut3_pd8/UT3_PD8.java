/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ut3_pd8;

/**
 *
 * @author TomasUcu
 */
public class UT3_PD8 {
    public static void main(String[] args) {
        ManejadorSucursales manejador = new ManejadorSucursales();
        manejador.cargarSucursales();
// USO DEL ARCHIVO suc1.txt
        System.out.println(manejador.cantSucursales());
        System.out.println(manejador.listarSucursales());
        
        manejador.quitarSucursal("Chicago");
        System.out.println(manejador.listarSucursales());
        
// USO DEL ARCHIVO suc2.txt
//        manejador.quitarSucursal("Shenzen");
//        manejador.quitarSucursal("Tokio");
//        System.out.println(manejador.cantSucursales());

// USO DEL ARCHIVO suc3.txt
//        System.out.println(manejador.listarSucursales(";_"));
    }
}
