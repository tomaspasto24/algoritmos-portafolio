/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ut3_pd8;

/**
 *
 * @author TomasUcu
 */
interface ISucursal {
    public String retornarCiudad();
}

public class Sucursal implements ISucursal {
    private String nombreCiudad;

    public Sucursal(String nombre) {
        this.nombreCiudad = nombre;
    }
    
    public String retornarCiudad() {
        return this.nombreCiudad;
    }
}
