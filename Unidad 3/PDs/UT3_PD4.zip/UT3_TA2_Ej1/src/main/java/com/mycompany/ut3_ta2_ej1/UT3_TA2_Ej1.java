/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ut3_ta2_ej1;

import static ut3.ta2.ManejadorArchivosGenerico.leerArchivo;

/**
 *
 * @author TomasUcu
 */
public class UT3_TA2_Ej1 {

    public static void main(String[] args) {
        IAlmacen almacen = new Almacen();
        Compras(almacen);
        Ventas(almacen);        
    }
    
    public static void Compras(IAlmacen almacen) {
        Integer montoStock = 0;
        Integer dineroGastado = 0;
        String[] lineas = leerArchivo("altas.txt");

        String codigoProducto;
        String descripcionProducto;
        Integer precioProducto;
        Integer cantidadProducto;
        IProducto producto = new Producto();

        for(String linea : lineas) {
            String[] info = linea.split(",");
            try {
                codigoProducto = info[0];
                descripcionProducto = info[1];
                precioProducto = Integer.parseInt(info[2]);
                cantidadProducto = Integer.parseInt(info[3]);            
            } catch(NumberFormatException e) {
                codigoProducto = info[0];
                descripcionProducto = info[1];
                precioProducto = 0;
                cantidadProducto = 0;
            }
            
            producto.setPrecio(precioProducto);
            producto.setStock(cantidadProducto);
            producto.setNombre(descripcionProducto);
            producto.setCodigo(codigoProducto);
            
            almacen.insertarProducto((Producto)producto);
            
            montoStock += cantidadProducto;
            dineroGastado += precioProducto;
        }
        
        System.out.println("Dinero gastado en las compras: $" + dineroGastado);
        System.out.println("Stock comprado: " + montoStock);
    }

    public static void Ventas(IAlmacen almacen) {
        Integer montoStockVendido = 0;
        String[] lineas = leerArchivo("ventas.txt");

        String codigoProducto;
        Integer cantidadVender;
        IProducto producto = new Producto();

        for(String linea : lineas) {
            String[] info = linea.split(",");
            codigoProducto = info[0];
            cantidadVender = Integer.parseInt(info[1]);
                
            IProducto productoAvender = almacen.buscarPorCodigo(codigoProducto);
            if(productoAvender != null) {
                if(productoAvender.getStock() < cantidadVender) {
                    cantidadVender = productoAvender.getStock();
                }                
                almacen.restarStock(codigoProducto, cantidadVender);
                montoStockVendido += cantidadVender;
            }
            
        }
        
        System.out.println("Stock vendido: " + montoStockVendido);
    }
}
