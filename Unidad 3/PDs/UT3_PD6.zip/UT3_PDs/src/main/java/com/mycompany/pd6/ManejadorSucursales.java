/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pd6;

/**
 *
 * @author TomasUcu
 */
public class ManejadorSucursales implements IManejadorSucursales {
    
    private ILista<ISucursal> lista = new Lista();
    
    public ManejadorSucursales() {
        
    }
    
    @Override
    public void agregarSucursal(Sucursal sucursal) {
        INodo nodo = new Nodo(sucursal.retornarCiudad(), sucursal);
        lista.insertar((Nodo)nodo);
    }

    @Override
    public Sucursal buscarSucursal(String clave) {
        return (Sucursal)this.lista.buscar(clave).getDato();
    }

    @Override
    public boolean quitarSucursal(String clave) {
        return this.lista.eliminar(clave);
    }

    @Override
    public String listarSucursales() {
        return this.lista.imprimir();
    }
    
    @Override
    public String listarSucursales(String separador) {
        return this.lista.imprimir(separador);
    }

    @Override
    public int cantSucursales() {
        return this.lista.cantElementos();
    }

    @Override
    public boolean esVacio() {
        return this.lista.esVacia();
    }
    
    public void cargarSucursales() {
        String[] lineas = ManejadorArchivosGenerico.leerArchivo("sucursales.txt");
        for(String linea : lineas) {
            lista.insertar(new Nodo<ISucursal>(linea, new Sucursal(linea)));
        }
    }
}
