/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pd6;

/**
 *
 * @author TomasUcu
 */
public class Main {
    public static void main(String[] args) {
        ManejadorSucursales manejador = new ManejadorSucursales();
        manejador.cargarSucursales();
// USO DEL ARCHIVO suc1.txt
//        System.out.println(manejador.cantSucursales());
//        System.out.println("1) corresponde con el inciso d)");
//        System.out.println(manejador.listarSucursales());
//        
//        manejador.quitarSucursal("Chicago");
//        System.out.println(manejador.listarSucursales());
//        System.out.println("2) corresponde con el inciso c)");
        
// USO DEL ARCHIVO suc2.txt
//        manejador.quitarSucursal("Shenzen");
//        manejador.quitarSucursal("Tokio");
//        System.out.println(manejador.cantSucursales());

// USO DEL ARCHIVO suc3.txt
        System.out.println(manejador.listarSucursales(";_"));
    }
}
