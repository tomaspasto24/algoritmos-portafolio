
/**
 *
 * @author ernesto
 * @param <T>
 */
public interface IConjunto<T> {

    
    public Conjunto union (Conjunto otroConjunto);

    public Conjunto interseccion (Conjunto otroConjunto);
}
