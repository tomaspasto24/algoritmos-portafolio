
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class ProgramaPD12 {

    public static void main(String[] args) throws IOException {
        Conjunto<Alumno> BasicoIng = new Conjunto<>();
        
        String[] lineas = ManejadorArchivosGenerico.leerArchivo("src/basico-ing.txt");
        
        
        for(String linea : lineas) {
            String[] alumnoInfo = linea.split(",");
            BasicoIng.insertar(new Nodo(Integer.parseInt(alumnoInfo[0]), alumnoInfo[1]));
        }
        
        
        Conjunto<Alumno> BasicoEmp = new Conjunto<>();

        lineas = ManejadorArchivosGenerico.leerArchivo("src/basico-emp.txt");

        for(String linea : lineas) {
            String[] alumnoInfo = linea.split(",");
            BasicoEmp.insertar(new Nodo(Integer.parseInt(alumnoInfo[0]), alumnoInfo[1]));
        }
        

        Conjunto<Alumno> integrador101 = BasicoIng.union(BasicoEmp);
        Conjunto<Alumno> integrador102 = BasicoIng.interseccion(BasicoEmp);
        
        String[] integrador101Lineas = new String[integrador101.tamano];
        
        Nodo<Alumno> primero = (Nodo)integrador101.primero;
        
        int cont = 0;
        
        while(primero != null) {
            integrador101Lineas[cont++] = primero.getEtiqueta() + "," + primero.getDato();
            primero = primero.getSiguiente();
        }
        
        ManejadorArchivosGenerico.escribirArchivo("src/Integrador101.txt", integrador101Lineas);
        
        
        String[] integrador102Lineas = new String[integrador102.tamano];
        
        Nodo<Alumno> aux = (Nodo)integrador102.primero;
        
        cont = 0;
        
        while(aux != null) {
            integrador102Lineas[cont++] = aux.getEtiqueta() + "," + aux.getDato();
            aux = aux.getSiguiente();
        }
        
        ManejadorArchivosGenerico.escribirArchivo("src/Integrador102.txt", integrador102Lineas);
        
    }

}
