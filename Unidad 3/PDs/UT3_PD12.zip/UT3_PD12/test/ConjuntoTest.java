/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author TomasUcu
 */
public class ConjuntoTest {
    
    public ConjuntoTest() {
    }

    @Test
    public void testUnion() {
        Conjunto<Integer> conjunto1 = new Conjunto();
        conjunto1.insertar(new Nodo(1, 1));
        conjunto1.insertar(new Nodo(2, 1));
        conjunto1.insertar(new Nodo(3, 1));
        conjunto1.insertar(new Nodo(4, 1));
        
        Conjunto<Integer> conjunto2 = new Conjunto();
        conjunto2.insertar(new Nodo(5, 1));
        conjunto2.insertar(new Nodo(6, 1));
        conjunto2.insertar(new Nodo(3, 1));
        conjunto2.insertar(new Nodo(4, 1));
        
        Conjunto<Integer> union = conjunto1.union(conjunto2);
        
        assertEquals(union.imprimir(), " 5 6 3 4 1 2");
    }
    
    @Test
    public void testInterseccion() {
        Conjunto<Integer> conjunto1 = new Conjunto();
        conjunto1.insertar(new Nodo(1, 1));
        conjunto1.insertar(new Nodo(2, 1));
        conjunto1.insertar(new Nodo(3, 1));
        conjunto1.insertar(new Nodo(4, 1));
        
        Conjunto<Integer> conjunto2 = new Conjunto();
        conjunto2.insertar(new Nodo(5, 1));
        conjunto2.insertar(new Nodo(6, 1));
        conjunto2.insertar(new Nodo(3, 1));
        conjunto2.insertar(new Nodo(4, 1));
        
        Conjunto<Integer> interseccion = conjunto1.interseccion(conjunto2);
        
        assertEquals(interseccion.imprimir(), " 3 4");
    }    

    
}
