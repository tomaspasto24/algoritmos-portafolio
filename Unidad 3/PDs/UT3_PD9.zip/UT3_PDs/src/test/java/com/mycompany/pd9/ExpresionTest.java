/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.pd9;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author TomasUcu
 */
public class ExpresionTest {
    
    public ExpresionTest() {
    }
    
    @org.junit.jupiter.api.Test
    public void testControlCorchetes() {
        assertTrue(Expresion.controlCorchetes("{}".split("")));
        assertFalse(Expresion.controlCorchetes("{{".split("")));
        assertFalse(Expresion.controlCorchetes("}}".split("")));
    }
    
    @Test
    public void testSinCorchetes() {
        assertTrue(Expresion.controlCorchetes("Hola ".split("")));
        assertTrue(Expresion.controlCorchetes("Hola que".split("")));
        assertTrue(Expresion.controlCorchetes("Hola que tal".split("")));
    }
    
    @Test
    public void testLoremIpsum() {
        assertTrue(Expresion.controlCorchetes("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas placerat bibendum pretium. Cras ultrices condimentum enim, vel efficitur velit aliquam id. Nullam ac sapien sit amet enim pellentesque eleifend.".split("")));
    }
}
