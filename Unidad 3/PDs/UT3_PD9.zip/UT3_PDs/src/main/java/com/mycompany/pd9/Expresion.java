/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pd9;

import java.util.Stack;

/**
 *
 * @author TomasUcu
 */
public class Expresion {
    
    public static void main(String[] args) {
        System.out.println(controlCorchetes("{}".split("")));
        System.out.println(controlCorchetes("}}{{".split("")));
        System.out.println(controlCorchetes("{{}}".split("")));
        System.out.println(controlCorchetes("{{".split("")));
        System.out.println(controlCorchetes("}}".split("")));
        System.out.println(controlCorchetes("Hola".split("")));
    }
    
    public static boolean controlCorchetes(String[] entrada) {
        Stack<String> pila = new Stack<String>();
        for(String c : entrada) {
            if(c.equals("{")) {
                pila.push(c);
            } else if (c.equals("}")) {
                if(pila.empty()) {
                    return false;
                } else {
                    pila.pop();                    
                }
            }
        }
        return pila.empty();
    }
}
