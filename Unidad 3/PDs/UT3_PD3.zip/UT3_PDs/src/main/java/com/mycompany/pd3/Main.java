/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pd3;

/**
 *
 * @author TomasUcu
 */
public class Main {
    public static void main(String[] args) {
        INodo<Integer> nodo1 = new Nodo<Integer>("1", 1);
        INodo<Integer> nodo2 = new Nodo<Integer>("2", 2);
        INodo<Integer> nodo3 = new Nodo<Integer>("3", 3);
        INodo<Integer> nodo4 = new Nodo<Integer>("4", 4);
        
        nodo1.setSiguiente((Nodo)nodo2);
        nodo2.setSiguiente((Nodo)nodo3);
        nodo3.setSiguiente((Nodo)nodo4);
        
        Lista<Integer> lista = new Lista(nodo1);
        lista.setPrimero((Nodo)nodo1);
        System.out.println(lista.imprimir());
        
        System.out.println(lista.buscar("3").getEtiqueta());
        
        System.out.println(lista.cantElementos());
        System.out.println(lista.eliminar("3"));
        System.out.println(lista.cantElementos());
        lista.insertar(new Nodo<Integer>("10", 10));
        System.out.println(lista.imprimir());
    }
}
