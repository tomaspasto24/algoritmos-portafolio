/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ut3_pd13;

/**
 *
 * @author TomasUcu
 * @param <T>
 */
public class Pila<T> extends Lista<T> {
    
    @Override
    public void insertar(Nodo<T> nodo) {
        nodo.setSiguiente((Nodo)this.primero);
        this.setPrimero(nodo);
    }
    // Se crea un nuevo método para eliminar y no se hace override del implementado 
    // en lista porque el nuevo método devuelve el nodo eliminado para poder ser usado.
    // Y siempre elimina el último elemento, no el ingresado por parámetro.
    public INodo<T> pop() {
        if(this.primero == null) {
            return null;
        }
        INodo<T> nodoActual = this.primero;
        INodo<T> nodoProx = nodoActual.getSiguiente();
        
        this.setPrimero((Nodo)nodoProx);
        nodoActual.setSiguiente(null);
        
        return nodoActual;
    }

    @Override
    public Nodo<T> retornarPrimero() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    @Override
    public boolean eliminar(Comparable clave) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
