/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ut3_pd13;

/**
 *
 * @author TomasUcu
 * @param <T>
 */
public class Cola<T> extends Lista<T> {
    
    public INodo<T> pop() {
        if(this.primero == null) {
            return null;
        }
        INodo<T> nodoActual = this.primero;
        INodo<T> nodoProx = nodoActual.getSiguiente();
        
        this.setPrimero((Nodo)nodoProx);
        nodoActual.setSiguiente(null);
        
        return nodoActual;
        
    }
    
    public void imprimirCola() {     
        INodo nodoActual = this.primero;
        while(nodoActual != null) {
            System.out.print(nodoActual.getEtiqueta() + " ");
            nodoActual = nodoActual.getSiguiente();
        }
    }
    
    @Override
    public boolean eliminar(Comparable clave) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
