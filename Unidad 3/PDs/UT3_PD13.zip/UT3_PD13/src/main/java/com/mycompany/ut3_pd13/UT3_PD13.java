/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ut3_pd13;

/**
 *
 * @author TomasUcu
 */
public class UT3_PD13 {

    public static void main(String[] args) {
        Pila<Integer> pila = new Pila();      
        INodo<Integer> nodo1 = new Nodo<Integer>("1", 1);
        INodo<Integer> nodo2 = new Nodo<Integer>("2", 2);
        INodo<Integer> nodo3 = new Nodo<Integer>("3", 3);
        INodo<Integer> nodo4 = new Nodo<Integer>("4", 4);
        
        pila.insertar((Nodo)nodo1);
        pila.insertar((Nodo)nodo2);
        pila.insertar((Nodo)nodo3);
        pila.insertar((Nodo)nodo4);
        
        System.out.println(pila.imprimir());
        
        System.out.println(pila.pop().getEtiqueta());
        
        System.out.println(pila.imprimir());
        
        System.out.println(pila.pop().getEtiqueta());
        
        System.out.println(pila.imprimir());
        
        System.out.println("////////////////////////////////");
        Cola<Integer> cola = new Cola();
        
        cola.insertar((Nodo)nodo1);
        cola.insertar((Nodo)nodo2);
        cola.insertar((Nodo)nodo3);
        cola.insertar((Nodo)nodo4);

        System.out.println(cola.imprimir());

        System.out.println(cola.pop().getEtiqueta());
        
        System.out.println(cola.imprimir());
        
        System.out.println(cola.pop().getEtiqueta());
        
        System.out.println(cola.imprimir());
    }
}
