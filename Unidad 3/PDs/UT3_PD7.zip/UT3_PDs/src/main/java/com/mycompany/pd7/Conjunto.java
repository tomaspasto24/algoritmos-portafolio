/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pd7;

/**
 *
 * @author TomasUcu
 */
public class Conjunto<T> extends Lista<T> implements IConjunto<T> {

    @Override
    public IConjunto<T> union(IConjunto<T> otroConjunto) {
        if(this.esVacia()) return otroConjunto;
        if( otroConjunto.esVacia()) return this;

        INodo nodoA = this.primero;
        while(nodoA != null) {
            if(!otroConjunto.buscar(nodoA.getEtiqueta())) {
                otroConjunto.insertar((Nodo)nodoA);
            }
            nodoA = nodoA.getSiguiente();
        }
        return otroConjunto;
    }

    @Override
    public IConjunto<T> interseccion(IConjunto<T> otroConjunto) {
        if(this.esVacia() || otroConjunto.esVacia()) return null;
        IConjunto<T> conjunto = new Conjunto();
        INodo nodoActual = this.primero;
        
        while(nodoActual != null) {
            if(!otroConjunto.buscar(nodoActual.getEtiqueta())) {
                conjunto.insertar((Nodo)nodoActual);
            }
            nodoActual = nodoActual.getSiguiente();
        }
        return conjunto;
    }
    
}
