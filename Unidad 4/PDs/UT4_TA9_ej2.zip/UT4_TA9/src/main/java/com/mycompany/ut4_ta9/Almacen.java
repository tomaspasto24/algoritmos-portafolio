package com.mycompany.ut4_ta9;

public class Almacen {

    private String nombre;
    private String direccion;
    private String telefono;

    private ArbolBB<Producto> productos;

    public Almacen(String nombre) {
        this.nombre = nombre;
        this.productos = new ArbolBB<Producto>();
    }

    public void insertarProducto(Producto unProducto) {
        productos.insertar(new ElementoAB<>(unProducto.getEtiqueta(), unProducto));
    }

    public String imprimirProductos() {
        return productos.preOrden();
    }

    public Boolean agregarStock(Comparable clave, Integer cantidad) {
        Producto prod = (productos.buscar(clave) != null) ? productos.buscar(clave).getDatos() : null;
        if(prod != null) {
            prod.agergarStock(cantidad);
            return true;
        }
        return false;
    }

    public Integer restarStock(Comparable clave, Integer cantidad) {
        Producto prod = (productos.buscar(clave) != null) ? productos.buscar(clave).getDatos() : null;
        if(prod != null) {
            prod.restarStock(cantidad);
            return prod.getStock();    
        }
        return 0;
    }

    public Producto buscarPorCodigo(Comparable clave) {
        return productos.buscar(clave).getDatos();
    }

    public boolean eliminarProducto(Comparable clave) {
        Producto prod = (productos.buscar(clave) != null) ? productos.buscar(clave).getDatos() : null;
        if(prod != null) {
            productos.eliminar(clave);
            return true;
        }
        return false;
    }
   
 
   


  

   

   

   

}
