
package com.mycompany.ut4_ta9;

public class Main {

    /**
     * @param args
     */
    public static void main(String[] args) {
        Almacen almacen = new Almacen("Almacen");
        String[] lineas = ManejadorArchivosGenerico.leerArchivo("src/main/java/com/mycompany/ut4_ta9/altasPrueba.txt");
        
        Comparable codigo;
        String nombre;
        Integer precio;
        Integer stock;
        
        int contProductos = 0;
        
        System.out.println("Lista de productos: ");

        for(String linea : lineas) {
            String[] componentes = linea.split(",");
            codigo = componentes[0];
            nombre = componentes[1];
            precio = Integer.parseInt(componentes[2]);
            stock = Integer.parseInt(componentes[3]);
            

            Producto prod = new Producto(codigo, nombre);
            prod.setStock(stock);
            prod.setPrecio(precio);
            
            almacen.insertarProducto(prod);
            contProductos++;
            System.out.print("Código: " + codigo + " Stock: " + stock + " Nombre: " + nombre);
        }
        
        String prods = almacen.imprimirProductos();
        
        String[] lineasEscritura = prods.split(",");
        
        ManejadorArchivosGenerico.escribirArchivo("src/main/java/com/mycompany/ut4_ta9/productos.txt", lineasEscritura);
    }
}

