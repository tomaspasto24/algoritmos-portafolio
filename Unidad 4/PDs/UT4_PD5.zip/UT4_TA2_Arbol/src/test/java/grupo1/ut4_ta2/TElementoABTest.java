/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package grupo1.ut4_ta2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author TomasUcu
 */
public class TElementoABTest {
    
    public TElementoABTest() {
    }

    @Test
    public void testObtenerMenorClaveConInsertar() {
        TElementoAB<Integer> nodo1 = new TElementoAB(3, 3);
        TElementoAB<Integer> nodo2 = new TElementoAB(5, 5);
        TElementoAB<Integer> nodo3 = new TElementoAB(10, 10);
        TElementoAB<Integer> nodo4 = new TElementoAB(1, 1);
        TElementoAB<Integer> nodo5 = new TElementoAB(20, 20);
        TArbolBB<Integer> arbol = new TArbolBB<>();
        arbol.insertar(nodo1);
        arbol.insertar(nodo2);
        arbol.insertar(nodo3);
        arbol.insertar(nodo4);
        arbol.insertar(nodo5);
        
        assertEquals(arbol.obtenerMenorClave(), 1);
    }
    
    @Test
    public void testObtenerMenorClaveConArbolVacio() {
        TArbolBB<Integer> arbol = new TArbolBB<>();
        
        assertEquals(arbol.obtenerMenorClave(), null);
    }
    
    @Test
    public void testObtenerMenorClaveSinInsertar() {
        TElementoAB<Integer> nodo1 = new TElementoAB(7, 7);
        TElementoAB<Integer> nodo2 = new TElementoAB(5, 5);
        TElementoAB<Integer> nodo4 = new TElementoAB(1, 1);
        
        nodo2.setHijoDer(nodo1);
        nodo2.setHijoIzq(nodo4);
        
        TArbolBB<Integer> arbol = new TArbolBB<>(nodo2);
        
        
        assertEquals(arbol.obtenerMenorClave(), 1);
    }
    
    @Test
    public void testObtenerMayorClaveConInsertar() {
        TElementoAB<Integer> nodo1 = new TElementoAB(3, 3);
        TElementoAB<Integer> nodo2 = new TElementoAB(5, 5);
        TElementoAB<Integer> nodo3 = new TElementoAB(10, 10);
        TElementoAB<Integer> nodo4 = new TElementoAB(1, 1);
        TElementoAB<Integer> nodo5 = new TElementoAB(20, 20);
        TArbolBB<Integer> arbol = new TArbolBB<>();
        arbol.insertar(nodo1);
        arbol.insertar(nodo2);
        arbol.insertar(nodo3);
        arbol.insertar(nodo4);
        arbol.insertar(nodo5);
        
        assertEquals(arbol.obtenerMayorClave(), 20);
    }
    
    @Test
    public void testObtenerMayorClaveConArbolVacio() {
        TArbolBB<Integer> arbol = new TArbolBB<>();
        
        assertEquals(arbol.obtenerMayorClave(), null);
    }
    
    @Test
    public void testObtenerMayorClaveSinInsertar() {
        TElementoAB<Integer> nodo1 = new TElementoAB(7, 7);
        TElementoAB<Integer> nodo2 = new TElementoAB(5, 5);
        TElementoAB<Integer> nodo4 = new TElementoAB(1, 1);
        
        nodo2.setHijoDer(nodo1);
        nodo2.setHijoIzq(nodo4);
        
        TArbolBB<Integer> arbol = new TArbolBB<>(nodo2);
        
        
        assertEquals(arbol.obtenerMayorClave(), 7);
    }
    
    @Test
    public void testobtenerClaveAnteriorADada() {
        TElementoAB<Integer> nodo1 = new TElementoAB(3, 3);
        TElementoAB<Integer> nodo2 = new TElementoAB(5, 5);
        TElementoAB<Integer> nodo3 = new TElementoAB(10, 10);
        TElementoAB<Integer> nodo4 = new TElementoAB(1, 1);
        TElementoAB<Integer> nodo5 = new TElementoAB(20, 20);
        TElementoAB<Integer> nodo6 = new TElementoAB(-2, -2);
        TArbolBB<Integer> arbol = new TArbolBB<>();
        arbol.insertar(nodo1);
        arbol.insertar(nodo2);
        arbol.insertar(nodo3);
        arbol.insertar(nodo4);
        arbol.insertar(nodo5);
        arbol.insertar(nodo6);
        
        assertEquals(arbol.obtenerClaveAnteriorADada(20), 10);
        assertEquals(arbol.obtenerClaveAnteriorADada(5), 3);
        assertEquals(arbol.obtenerClaveAnteriorADada(1), 3);
        assertEquals(arbol.obtenerClaveAnteriorADada(-2), 1);
    }
    
    @Test
    public void testcantidadNodosPorAltura() {
        TElementoAB<Integer> nodo1 = new TElementoAB(3, 3);
        TElementoAB<Integer> nodo2 = new TElementoAB(5, 5);
        TElementoAB<Integer> nodo3 = new TElementoAB(10, 10);
        TElementoAB<Integer> nodo4 = new TElementoAB(1, 1);
        TElementoAB<Integer> nodo5 = new TElementoAB(20, 20);
        TElementoAB<Integer> nodo6 = new TElementoAB(-2, -2);
        TArbolBB<Integer> arbol = new TArbolBB<>();
        arbol.insertar(nodo1);
        arbol.insertar(nodo2);
        arbol.insertar(nodo3);
        arbol.insertar(nodo4);
        arbol.insertar(nodo5);
        arbol.insertar(nodo6);
        
        assertEquals(arbol.cantidadNodosPorAltura(2), 2);
        assertEquals(arbol.cantidadNodosPorAltura(0), 1);
        assertEquals(arbol.cantidadNodosPorAltura(3), 1);
    }
    
    @Test
    public void testlistarHojasConNivel() {
        TElementoAB<Integer> nodo1 = new TElementoAB(3, 3);
        TElementoAB<Integer> nodo2 = new TElementoAB(5, 5);
        TElementoAB<Integer> nodo3 = new TElementoAB(10, 10);
        TElementoAB<Integer> nodo4 = new TElementoAB(1, 1);
        TElementoAB<Integer> nodo5 = new TElementoAB(20, 20);
        TElementoAB<Integer> nodo6 = new TElementoAB(-2, -2);
        TArbolBB<Integer> arbol = new TArbolBB<>();
        arbol.insertar(nodo1);
        arbol.insertar(nodo2);
        arbol.insertar(nodo3);
        arbol.insertar(nodo4);
        arbol.insertar(nodo5);
        arbol.insertar(nodo6);
        
        arbol.listarHojasConNivel();
    }
    
    @Test
    public void testVerificarSiEsBusqueda() {
        TElementoAB<Integer> nodo1 = new TElementoAB(3, 3);
        TElementoAB<Integer> nodo2 = new TElementoAB(5, 5);
        TElementoAB<Integer> nodo3 = new TElementoAB(10, 10);
        TElementoAB<Integer> nodo4 = new TElementoAB(1, 1);
        TElementoAB<Integer> nodo5 = new TElementoAB(20, 20);
        TElementoAB<Integer> nodo6 = new TElementoAB(-2, -2);
        TArbolBB<Integer> arbol = new TArbolBB<>();
        arbol.insertar(nodo1);
        arbol.insertar(nodo2);
        arbol.insertar(nodo3);
        arbol.insertar(nodo4);
        arbol.insertar(nodo5);
        arbol.insertar(nodo6);
        
        assertTrue(arbol.verificarSiEsBusqueda());
    }
    
    @Test
    public void testVerificarSiEsBusquedaFalso() {
        TElementoAB<Integer> nodo1 = new TElementoAB(3, 3);
        TElementoAB<Integer> nodo2 = new TElementoAB(5, 5);
        TElementoAB<Integer> nodo3 = new TElementoAB(10, 10);
        TElementoAB<Integer> nodo4 = new TElementoAB(1, 1);
        TElementoAB<Integer> nodo5 = new TElementoAB(20, 20);
        TElementoAB<Integer> nodo6 = new TElementoAB(-2, -2);
        TArbolBB<Integer> arbol = new TArbolBB<>();
        nodo1.setHijoDer(nodo6);
        nodo1.setHijoIzq(nodo3);
        arbol.insertar(nodo1);
        
        assertFalse(arbol.verificarSiEsBusqueda());
    }
}
