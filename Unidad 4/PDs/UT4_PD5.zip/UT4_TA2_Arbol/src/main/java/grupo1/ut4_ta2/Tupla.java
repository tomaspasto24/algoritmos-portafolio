/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grupo1.ut4_ta2;

/**
 *
 * @author santi
 * @param <T>
 * @param <U>
 */
public class Tupla<T, U> {
    public T primero;
    public U segundo;
    
    public Tupla(T primero, U segundo) {
        this.primero = primero;
        this.segundo = segundo;
    }
}
