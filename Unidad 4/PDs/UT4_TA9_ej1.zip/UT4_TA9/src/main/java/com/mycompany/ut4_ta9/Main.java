
package com.mycompany.ut4_ta9;

public class Main {

    /**
     * @param args
     */
    public static void main(String[] args) {
        Almacen almacen = new Almacen("Almacen");
        String[] lineas = ManejadorArchivosGenerico.leerArchivo("src/main/java/com/mycompany/ut4_ta9/altasPrueba.txt");
        
        Comparable codigo;
        String nombre;
        Integer precio;
        Integer stock;

        System.out.println("Lista de productos: ");

        for(String linea : lineas) {
            String[] componentes = linea.split(",");
            codigo = componentes[0];
            nombre = componentes[1];
            precio = Integer.parseInt(componentes[2]);
            stock = Integer.parseInt(componentes[3]);
            

            Producto prod = new Producto(codigo, nombre);
            prod.setStock(stock);
            prod.setPrecio(precio);
            
            almacen.insertarProducto(prod);
            System.out.print("Código: " + codigo + " Stock: " + stock + " Nombre: " + nombre);
        }
        
        lineas = ManejadorArchivosGenerico.leerArchivo("src/main/java/com/mycompany/ut4_ta9/ventasPrueba.txt");
        
        System.out.println("Lista de ventas: ");        
        for(String linea : lineas) {
            String[] componentesVender = linea.split(",");
            codigo = componentesVender[0];
            stock = Integer.parseInt(componentesVender[1]);
            int stockrestante = almacen.restarStock(codigo, stock);
            System.out.print("Código: " + codigo + " Stock: -" + stock+ " Stock restante: " + stockrestante);            
        }

        lineas = ManejadorArchivosGenerico.leerArchivo("src/main/java/com/mycompany/ut4_ta9/elimPrueba.txt");
        
        for(String linea : lineas) {
            System.out.println("Codigo eliminado: " + linea);
            almacen.eliminarProducto(linea);
        }
        
        System.out.println("Lista nueva de productos ordenados: " + almacen.imprimirProductos());
        // listar los productos ordenados por codigo, junto con su cantidad existente

    }
}

