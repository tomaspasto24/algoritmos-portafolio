/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.ut4_pd2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author TomasUcu
 */
public class TArbolBBTest {
    
    public TArbolBBTest() {
    }
    @Test
    public void testBasicoCincoNodos() {
        TArbolBB<Integer> arbol = new TArbolBB<>();
        arbol.insertar(new ElementoAB<>(3, 3));
        arbol.insertar(new ElementoAB<>(10, 10));
        arbol.insertar(new ElementoAB<>(15, 15));
        arbol.insertar(new ElementoAB<>(22, 22));
        arbol.insertar(new ElementoAB<>(1, 1));
        
        System.out.println("Preorden: " + arbol.preOrden());
        System.out.println("Postorden: " + arbol.postOrden());
        System.out.println("Inorden: " + arbol.inOrden());
    }

    @Test
    public void testArchivoClavesPrueba() {
        TArbolBB<Integer> arbol = new TArbolBB<>();
        String[] lineas = ManejadorArchivosGenerico.leerArchivo("src/claves1.txt");
        for(String linea : lineas) {
            Integer numero = Integer.parseInt(linea);
            arbol.insertar(new ElementoAB<>(numero, numero));
        }
        
        System.out.println("Preorden: " + arbol.preOrden());
        System.out.println("Postorden: " + arbol.postOrden());
        System.out.println("Inorden: " + arbol.inOrden());
        String[] preorden = new String[1];
        preorden[0] = arbol.preOrden();
        String[] postorden = new String[1];
        postorden[0] = arbol.postOrden();
        String[] inOrden = new String[1];
        inOrden[0] = arbol.inOrden();
        ManejadorArchivosGenerico.escribirArchivo("preOrden.txt", preorden);
        ManejadorArchivosGenerico.escribirArchivo("preOrden.txt", postorden);
        ManejadorArchivosGenerico.escribirArchivo("preOrden.txt", inOrden);
    }

    @Test
    public void testArchivoClavesPruebaBuscar() {
        TArbolBB<Integer> arbol = new TArbolBB<>();
        String[] lineas = ManejadorArchivosGenerico.leerArchivo("src/claves1.txt");
        for(String linea : lineas) {
            Integer numero = Integer.parseInt(linea);
            arbol.insertar(new ElementoAB<>(numero, numero));
        }
        
        assertAll("Deberían retornar null menos el primero",
            () -> assertNotNull(arbol.buscar(10635)),
            () -> assertNull(arbol.buscar(4567)),
            () -> assertNull(arbol.buscar(12)),
            () -> assertNull(arbol.buscar(8978))
        );
    }
    
}
