/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ut4_pd2;

/**
 *
 * @author TomasUcu
 */
public class ElementoAB<T> implements IElementoAB<T> {
    
    protected IElementoAB<T> hijoIzq;
    protected IElementoAB<T> hijoDer;
    protected Comparable etiqueta;
    protected T dato;
    
    public ElementoAB(Comparable etiqueta, T dato) {
        this.etiqueta = etiqueta;
        this.dato = dato;
    }

    @Override
    public Comparable getEtiqueta() {
        return this.etiqueta;
    }

    @Override
    public IElementoAB<T> getHijoIzq() {
        return this.hijoIzq;
    }

    @Override
    public IElementoAB<T> getHijoDer() {
        return this.hijoDer;
    }

    @Override
    public void setHijoIzq(IElementoAB<T> elemento) {
        this.hijoIzq = elemento;
    }

    @Override
    public void setHijoDer(IElementoAB<T> elemento) {
        this.hijoDer = elemento;
    }

    @Override
    public IElementoAB<T> buscar(Comparable unaEtiqueta) {
        int comparacion = etiqueta.compareTo(unaEtiqueta);
        if(comparacion == 0) {
            return this;
        } else if (comparacion < 0) {
            if(hijoDer == null) return null;
            return hijoDer.buscar(unaEtiqueta);
        } else {
            if(hijoIzq == null) return null;            
            return hijoIzq.buscar(unaEtiqueta);
        }
    }

    @Override
    public boolean insertar(IElementoAB<T> elemento) {
        int comp = this.etiqueta.compareTo(elemento.getEtiqueta());
        if(comp == 0) {
            return false;
        } else if(comp < 0) {
            if(hijoDer == null){
                hijoDer = elemento;
            } else {
                hijoDer.insertar(elemento);
            }
        } else {
            if(hijoIzq == null){
                hijoIzq = elemento;
            } else {
                hijoIzq.insertar(elemento);
            }
        }
        return true;
    }

    @Override
    public String preOrden() {
        String cadenaThis = this.etiqueta.toString();
        
        String cadenaIzq = "";
        if(this.hijoIzq != null) {
             cadenaIzq = ", " + this.hijoIzq.preOrden();
        }
        
        String cadenaDer = "";
        
        if(this.hijoDer != null) {
            cadenaDer = ", " + this.hijoDer.preOrden();
        }
        
        return cadenaThis + cadenaIzq + cadenaDer;
    }

    @Override
    public String inOrden() {
        String izqStr = "";
        if (this.hijoIzq != null) {
            izqStr = this.hijoIzq.inOrden() + ", ";
        }
        
        String thisValue = this.getEtiqueta().toString();
        
        String derStr = "";
        if (this.hijoDer != null) {
            derStr = ", " + this.hijoDer.inOrden();
        }
        
        return izqStr + thisValue + derStr;
    }

    @Override
    public String postOrden() {
        String izqStr = "";
        if(this.hijoIzq != null) {
            izqStr = this.hijoIzq.postOrden() + ", ";
        }
        String derStr = "";        
        if(hijoDer != null) {
            derStr = hijoDer.postOrden() + ", ";
        }
        String thisValue = etiqueta.toString();        
        return izqStr + derStr + thisValue;
    }

    @Override
    public T getDatos() {
        return this.dato;
    }

    @Override
    public IElementoAB eliminar(Comparable unaEtiqueta) {
//        int comparacion = etiqueta.compareTo(unaEtiqueta);
//        if(comparacion > 0) {
//            if(hijoIzq != null) return hijoIzq.eliminar(unaEtiqueta);
//            return this;
//        } else if(comparacion < 0) {
//            if(hijoDer != null) return hijoDer.eliminar(unaEtiqueta);
//            return this;
//        }
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
