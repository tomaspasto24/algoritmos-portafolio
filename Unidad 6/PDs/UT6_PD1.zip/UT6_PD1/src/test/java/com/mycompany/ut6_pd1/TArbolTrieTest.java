/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.ut6_pd1;

import java.time.Duration;
import java.time.Instant;
import static java.time.Instant.now;
import java.util.LinkedList;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author TomasUcu
 */
public class TArbolTrieTest {
    
    public TArbolTrieTest() {
    }

    @Test
    public void testInsertar() {
        String[] cadenas = ManejadorArchivosGenerico.leerArchivo("src/main/java/com/mycompany/ut6_pd1/palabras1.txt");
        TArbolTrie trie = new TArbolTrie();
        
        for(String s : cadenas) {
            trie.insertar(s);
        }
        
        Instant before = now();                

        long start = System.currentTimeMillis();
        LinkedList<String> lista = trie.predecir("coca-cola");
        long finish = System.currentTimeMillis();
        long timeElapsed = finish - start;
        // No sé por qué sale 0.
        System.out.println("La demora en el peor caso es: " + timeElapsed + " mili seg");
    }

    @Test
    public void testPredecir() {
    }
    
}
