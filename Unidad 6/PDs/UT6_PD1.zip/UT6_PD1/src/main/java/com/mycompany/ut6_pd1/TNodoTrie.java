package com.mycompany.ut6_pd1;


import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;

public class TNodoTrie implements INodoTrie {

    private char letra;
    private HashMap<Comparable, TNodoTrie> hijos;
    private boolean esPalabra;

    public TNodoTrie(char l) {
        hijos = new HashMap<>();
        esPalabra = false;
        letra = l;
    }

    @Override
    public void insertar(String unaPalabra) {
        TNodoTrie nodo = this;
        for (int c = 0; c < unaPalabra.length(); c++) {
            int indice = unaPalabra.charAt(c) - 'a';
            TNodoTrie nodo2 = new TNodoTrie(unaPalabra.charAt(c));
            if(unaPalabra.length() == c + 1) {
                nodo2.esPalabra = true;
            }
            if(!nodo.hijos.containsKey(unaPalabra.charAt(c))) {
                nodo.hijos.put(unaPalabra.charAt(c), nodo2);
            }
            nodo = nodo.hijos.get(unaPalabra.charAt(c));
        }
    }

    private void imprimir(String s, TNodoTrie nodo) {
        if (nodo != null) {
            if (nodo.esPalabra) {
                System.out.println(s);
            }
            Collection siguientes = nodo.hijos.values();
            for(var aux : siguientes) {
                if(aux != null) {
                    TNodoTrie nodo2 = (TNodoTrie) aux;
                    imprimir(s + nodo2.letra, nodo2);
                }
            }
        }
    }

    @Override
    public void imprimir() {
        
        imprimir("", this);
    }
    
      private TNodoTrie buscarNodoTrie(String s) {        
        TNodoTrie nodo = this;
        for (int c = 0; c < s.length(); c++) {
            int indice = s.charAt(c) - 'a';
            if (nodo.hijos.containsKey(s.charAt(c))) {
                return null;
            }
            nodo = nodo.hijos.get(s.charAt(c));
        }
        return nodo;
    }
    
    private void predecir(String s, LinkedList<String> palabras, TNodoTrie nodo) {
        if (nodo.esPalabra) {
            palabras.add(s);
        }
        Collection siguientes = hijos.values();
        for (var aux : siguientes) {
            if (aux != null) {
                TNodoTrie nodo2 = (TNodoTrie) aux;
                predecir(s + nodo2.letra, palabras, nodo2);
            }
        }
    }

    @Override
    public void predecir(String prefijo, LinkedList<String> palabras) {
        TNodoTrie aux = this.buscarNodoTrie(prefijo);
        if (aux != null) {
            aux.predecir(prefijo, palabras, aux);
        }
    }

    @Override
    public int buscar(String s) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
  
}
