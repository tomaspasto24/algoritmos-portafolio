/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.ut6_pd1;

/**
 *
 * @author jechague
 */
public interface IHash {
    
    public int buscar(int unaClave);
    public int insertar(int unaClave);
    public int funcionHashing(int unaClave);
}
