/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ut6_pd2;

/**
 *
 * @author TomasUcu
 */
public class UT6_PD2 {

    public static void main(String[] args) {
        Hash hash = new Hash(100);  
        for(int i = 0; i < 70; i++) {
            hash.insertar(i);            
        }
        System.out.println("Factor de carga 70%");
        System.out.println("Promedio comparaciones Inserción: " + promComparacionesInsercion(hash));            
        System.out.println("Promedio comparaciones busqueda exitosa: " + promComparacionesBusquedaConExito(hash));            
        System.out.println("Promedio comparaciones busqueda sin éxito: " + promComparacionesBusquedaSinExito(hash));            

        for(int i = 70; i < 75; i++) {
            hash.insertar(i);            
        }
        System.out.println("Factor de carga 75%");
        System.out.println("Promedio comparaciones Inserción: " + promComparacionesInsercion(hash));            
        System.out.println("Promedio comparaciones busqueda exitosa: " + promComparacionesBusquedaConExito(hash));            
        System.out.println("Promedio comparaciones busqueda sin éxito: " + promComparacionesBusquedaSinExito(hash));
        
        for(int i = 75; i < 80; i++) {
            hash.insertar(i);            
        }
        System.out.println("Factor de carga 80%");
        System.out.println("Promedio comparaciones Inserción: " + promComparacionesInsercion(hash));            
        System.out.println("Promedio comparaciones busqueda exitosa: " + promComparacionesBusquedaConExito(hash));            
        System.out.println("Promedio comparaciones busqueda sin éxito: " + promComparacionesBusquedaSinExito(hash)); 
        
        for(int i = 80; i < 85; i++) {
            hash.insertar(i);            
        }
        System.out.println("Factor de carga 85%");
        System.out.println("Promedio comparaciones Inserción: " + promComparacionesInsercion(hash));            
        System.out.println("Promedio comparaciones busqueda exitosa: " + promComparacionesBusquedaConExito(hash));            
        System.out.println("Promedio comparaciones busqueda sin éxito: " + promComparacionesBusquedaSinExito(hash)); 

        for(int i = 85; i < 90; i++) {
            hash.insertar(i);            
        }
        System.out.println("Factor de carga 90%");
        System.out.println("Promedio comparaciones Inserción: " + promComparacionesInsercion(hash));            
        System.out.println("Promedio comparaciones busqueda exitosa: " + promComparacionesBusquedaConExito(hash));            
        System.out.println("Promedio comparaciones busqueda sin éxito: " + promComparacionesBusquedaSinExito(hash)); 

        hash.insertar(90);
        System.out.println("Factor de carga 91%");
        System.out.println("Promedio comparaciones Inserción: " + promComparacionesInsercion(hash));            
        System.out.println("Promedio comparaciones busqueda exitosa: " + promComparacionesBusquedaConExito(hash));            
        System.out.println("Promedio comparaciones busqueda sin éxito: " + promComparacionesBusquedaSinExito(hash)); 

        hash.insertar(91);
        System.out.println("Factor de carga 92%");
        System.out.println("Promedio comparaciones Inserción: " + promComparacionesInsercion(hash));            
        System.out.println("Promedio comparaciones busqueda exitosa: " + promComparacionesBusquedaConExito(hash));            
        System.out.println("Promedio comparaciones busqueda sin éxito: " + promComparacionesBusquedaSinExito(hash)); 

        hash.insertar(92);
        System.out.println("Factor de carga 93%");
        System.out.println("Promedio comparaciones Inserción: " + promComparacionesInsercion(hash));            
        System.out.println("Promedio comparaciones busqueda exitosa: " + promComparacionesBusquedaConExito(hash));            
        System.out.println("Promedio comparaciones busqueda sin éxito: " + promComparacionesBusquedaSinExito(hash)); 

        hash.insertar(93);
        System.out.println("Factor de carga 94%");
        System.out.println("Promedio comparaciones Inserción: " + promComparacionesInsercion(hash));            
        System.out.println("Promedio comparaciones busqueda exitosa: " + promComparacionesBusquedaConExito(hash));            
        System.out.println("Promedio comparaciones busqueda sin éxito: " + promComparacionesBusquedaSinExito(hash)); 

        hash.insertar(94);
        System.out.println("Factor de carga 95%");
        System.out.println("Promedio comparaciones Inserción: " + promComparacionesInsercion(hash));            
        System.out.println("Promedio comparaciones busqueda exitosa: " + promComparacionesBusquedaConExito(hash));            
        System.out.println("Promedio comparaciones busqueda sin éxito: " + promComparacionesBusquedaSinExito(hash)); 

        hash.insertar(95);
        System.out.println("Factor de carga 96%");
        System.out.println("Promedio comparaciones Inserción: " + promComparacionesInsercion(hash));            
        System.out.println("Promedio comparaciones busqueda exitosa: " + promComparacionesBusquedaConExito(hash));            
        System.out.println("Promedio comparaciones busqueda sin éxito: " + promComparacionesBusquedaSinExito(hash)); 

        hash.insertar(96);
        System.out.println("Factor de carga 97%");
        System.out.println("Promedio comparaciones Inserción: " + promComparacionesInsercion(hash));            
        System.out.println("Promedio comparaciones busqueda exitosa: " + promComparacionesBusquedaConExito(hash));            
        System.out.println("Promedio comparaciones busqueda sin éxito: " + promComparacionesBusquedaSinExito(hash)); 

        hash.insertar(97);
        System.out.println("Factor de carga 98%");
        System.out.println("Promedio comparaciones Inserción: " + promComparacionesInsercion(hash));            
        System.out.println("Promedio comparaciones busqueda exitosa: " + promComparacionesBusquedaConExito(hash));            
        System.out.println("Promedio comparaciones busqueda sin éxito: " + promComparacionesBusquedaSinExito(hash)); 

        hash.insertar(98);
        System.out.println("Factor de carga 99%");
        System.out.println("Promedio comparaciones Inserción: " + promComparacionesInsercion(hash));            
        System.out.println("Promedio comparaciones busqueda exitosa: " + promComparacionesBusquedaConExito(hash));            
        System.out.println("Promedio comparaciones busqueda sin éxito: " + promComparacionesBusquedaSinExito(hash)); 
    }
    
    private static int promComparacionesBusquedaConExito(Hash h) {
        int promedio = 0;
        
        for(int j = 0; j < 100; j++) {
            promedio += busquedaConExito(h);
        }
        
        promedio /= 100;
        return promedio;
    }
    
    private static int busquedaConExito(Hash h) {
        int numeroRandom = (int)(Math.random() * 70); // Número random entre 0 y 70
        return h.buscar(numeroRandom);
    }
    
    private static int promComparacionesBusquedaSinExito(Hash h) {
        int promedio = 0;
        
        for(int j = 0; j < 100; j++) {
            promedio += busquedaSinExito(h);
        }
        
        promedio /= 100;
        return promedio;
    }
    
    private static int busquedaSinExito(Hash h) {
        int numeroRandom = 70 + (int)(Math.random() * 30); // Número random entre 70 y 100
        return h.buscar(numeroRandom);
    }
    
    private static int promComparacionesInsercion(Hash h) {
        int promedio = 0;
        
        for(int j = 0; j < 100; j++) {
            promedio += comparacionesInsercion(h);
        }
        
        promedio /= 100;
        return promedio;
    }
    private static int comparacionesInsercion(Hash h) {
        Hash hash = new Hash(100);  
        hash.setArr(h.retornarArr()); //Copia del hash ingresado, asi siempre es el mismo factor de carga.
                
        int numeroRandom = (int)(Math.random() * 100);
        
        return hash.insertar(numeroRandom);
    }
}
