/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ut6_pd4;

import java.util.HashMap;

/**
 *
 * @author TomasUcu
 */
public class UT6_PD4 {

    public static void main(String[] args) {
        ocurrenciasPalabras("src/main/java/com/mycompany/ut6_pd4/libro.txt");
    }
    
    public static void ocurrenciasPalabras(String rutaArchivo) {
        String[] lineas = ManejadorArchivosGenerico.leerArchivo(rutaArchivo);
        
        HashMap<String, Integer> map = new HashMap();
        
        for(String l : lineas) {
            String[] palabras = l.split(" ");
            for(String palabra : palabras) {
                palabra = comprobar(palabra);
                if(map.containsKey(palabra)) {
                    map.put(palabra, map.get(palabra) + 1);
                } else {
                    map.put(palabra, 1);
                }
            }
        }
        
        map.forEach((k,v) -> System.out.println(k + "," + v));
    }
    
    private static String comprobar(String cadena) {
        cadena = cadena.toLowerCase();
        char[] partes = cadena.toCharArray();
        StringBuilder string = new StringBuilder();
        int cont = 0;
        
        for(char c : partes) {
            int index = c-'a';
            if( index >= 0 && index <=25)
            {
                string.append(c);
            } 
        }
        return string.toString();
    }
}
