/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ut6_pd7;

/**
 *
 * @author TomasUcu
 */
public class UT6_PD7 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
