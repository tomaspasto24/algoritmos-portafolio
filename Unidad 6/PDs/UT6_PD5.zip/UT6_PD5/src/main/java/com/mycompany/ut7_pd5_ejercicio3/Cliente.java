/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ut7_pd5_ejercicio3;

/**
 *
 * @author TomasUcu
 */
public class Cliente {
    private String numero;
    private String nombre;
    
    public Cliente(String numero, String nombre) {
        this.nombre = nombre;
        this.numero = numero;
    }
    
    public String getNumero() {
        return numero;
    }
    
    public String getNombre() {
        return nombre;
    }
}
