package com.mycompany.ut7_pd5_ejercicio3;

import java.util.LinkedList;


public class ArbolTrieHashMap implements IArbolTrieHashMap {

    private NodoTrieHashMap raiz;

    @Override
    public void insertar(String numero, Cliente cliente) {
        if (raiz == null) {
            raiz = new NodoTrieHashMap();
        }
        raiz.insertar(numero, cliente);
    }

    @Override
    public void imprimir() {
        if (raiz != null) {
            raiz.imprimir();
        }
    }

    public void imprimirIndice() {
        if (raiz != null) {
            raiz.imprimirIndice();
        }
    }

    @Override
    public NodoTrieHashMap buscar(String palabra) {
        if(raiz != null) {
            return raiz.buscar(palabra);
        }
        return null;
    }

    @Override
    public LinkedList<String> predecir(String prefijo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public ArbolBB<Cliente> buscarTelefonos(String codigoPais, String codigoArea) {
        ArbolBB<Cliente> tree = new ArbolBB();
        if(raiz != null) {
            raiz.buscarTelefonos(codigoPais, codigoArea, tree);
        }
        return tree;
    }
}
