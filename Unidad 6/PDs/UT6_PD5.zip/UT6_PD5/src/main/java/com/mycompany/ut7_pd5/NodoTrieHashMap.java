
package com.mycompany.ut7_pd5;

import java.util.HashMap;
import java.util.LinkedList;

public class NodoTrieHashMap implements INodoTrieHashMap {

    private static final int CANT_CHR_ABECEDARIO = 26;
    private HashMap hijos = new HashMap<>();
    private boolean esPalabra;
    private Lista<Integer> paginas = new Lista<>();
    
    public NodoTrieHashMap() {
        esPalabra = false;
    }

    @Override
    public void insertar(String unaPalabra, Integer pagina) {
        unaPalabra = comprobar(unaPalabra);
        NodoTrieHashMap nodo = this;
        for (int c = 0; c < unaPalabra.length(); c++) {
            char indice = unaPalabra.charAt(c);
            if (!nodo.hijos.containsValue(indice)) {
                nodo.hijos.put(indice, new NodoTrieHashMap());
            }               
            nodo = (NodoTrieHashMap)nodo.hijos.get(indice);
        }
        nodo.esPalabra = true;
        nodo.paginas.insertar(new Nodo(pagina, pagina));
    }

    private void imprimir(String s, NodoTrieHashMap nodo) {
        if (nodo != null) {
            if (nodo.esPalabra) {
                System.out.println(s);
                
            }
            for (int c = 0; c < CANT_CHR_ABECEDARIO; c++) {
                if (nodo.hijos.containsKey((char)(c + 'a'))) {
                    imprimir(s+(char)(c + 'a'), (NodoTrieHashMap)nodo.hijos.get((char)(c + 'a')));
                }
            }
        }
    }

    @Override
    public void imprimir() {
        
        imprimir("", this);
    }
    
    private void imprimirIndice(String s, NodoTrieHashMap nodo) {
        if (nodo != null) {
            if (nodo.esPalabra) {
                System.out.println(s + " Paginas: " + nodo.getPaginas().imprimir());
                
            }
            for (int c = 0; c < CANT_CHR_ABECEDARIO; c++) {
                if (nodo.hijos.containsKey((char)(c + 'a'))) {
                    imprimirIndice(s+(char)(c + 'a'), (NodoTrieHashMap)nodo.hijos.get((char)(c + 'a')));
                }
            }
        }
    }

    public void imprimirIndice() {
        
        imprimirIndice("", this);
    }
    
      private NodoTrieHashMap buscarNodoTrie(String s) {
        NodoTrieHashMap nodo = this;
     
         // implementar
        
        return nodo;
    }
    
     private void predecir(String s, String prefijo, LinkedList<String> palabras, NodoTrieHashMap nodo) {
     // implementar
       
    }

    @Override
    public void predecir(String prefijo, LinkedList<String> palabras) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public NodoTrieHashMap buscar(String s) {
       int comp = 1; //incluyendo a la raíz
       s = s.toLowerCase();
       NodoTrieHashMap nodoActual = this;
       char [] partes = s.toCharArray();
       
       for(char m: partes) {
           NodoTrieHashMap unHijo = (NodoTrieHashMap)nodoActual.hijos.get(m);
           if(unHijo == null) 
           {
               comp++;
               System.out.println("No existe en el indice, cantidad de comparaciones: " + comp);
               return null;               
           } else {
               comp++;
               nodoActual = unHijo;               
           }
       }
       if(nodoActual.esPalabra) {
           comp++;
           System.out.println("Existe la palabra, cantidad de comparaciones: " + comp + " paginas: " + nodoActual.getPaginas().imprimir());
           return nodoActual;
       } else {
           comp++;
           return null;
       } 
    }
    
    public Lista<Integer> getPaginas() {
        return this.paginas;
    }
    
    public String comprobar(String cadena) {
        cadena = cadena.toLowerCase();
        char[] partes = cadena.toCharArray();
        StringBuilder string = new StringBuilder();
        int cont = 0;
        
        for(char c : partes) {
            int index = c-'a';
            if( index >= 0 && index <=25)
            {
                string.append(c);
            } 
        }
        return string.toString();
    }
  
}
