/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.ut7_pd5_ejercicio3;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author TomasUcu
 */
public class ArbolTrieHashMapTest {
//    
//    @Test
//    public void testInsertarTrieVacio() {
//        ArbolTrieHashMap trie = new ArbolTrieHashMap();
//        
//        trie.insertar("50239563102", new Cliente("50239563102", "Osvaldo"));
//        
//        ArbolBB<Cliente> arbol = trie.buscarTelefonos("502", "395");
//
//        assertEquals(arbol.raiz.getEtiqueta(), "Osvaldo");
//    }
//    
//    @Test
//    public void testInsertarTrieConElementos() {
//        ArbolTrieHashMap trie = new ArbolTrieHashMap();
//        Cliente cliente = new Cliente("90394857291", "Dexter");
//        
//        trie.insertar("50239563102", new Cliente("50239563102", "Osvaldo"));
//        trie.insertar("23321231244", new Cliente("23321231244", "Rafael"));
//        trie.insertar("12359502303", new Cliente("12359502303", "Marcos"));
//        trie.insertar("12359555620", new Cliente("12359555620", "Rita"));
//        trie.insertar("90394857291", cliente);
//  
//        
//        ArbolBB<Cliente> arbol = trie.buscarTelefonos("123", "595");
//
//        assertEquals(arbol.raiz.getEtiqueta(), "Marcos");
//        assertEquals(arbol.raiz.getHijoDer().getEtiqueta(), "Rita");
//        assertEquals(trie.buscar("90394857291").getCliente(), cliente);
//    }
//    
}
