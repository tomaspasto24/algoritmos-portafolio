/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.ut6_pd3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @author TomasUcu
 */
public class UT6_PD3 {

    public static void main(String[] args) {
        //Ejercicio 1
        HashMap<Integer, Integer> mapa = new HashMap();
        mapa.put(1, 1);
        mapa.put(2, 2);
        mapa.put(30, 30);
        mapa.put(42, 42);
        mapa.put(13, 13);
        mapa.put(9, null);
        eliminarEntradasNull(mapa);
        System.out.println(!mapa.containsKey(9));
        
        //Ejercicio 2
        HashMap<String, String> mapa2 = new HashMap();
        
        mapa2.put("clave1", "valor1");
        mapa2.put("clave2", "valor2");
        mapa2.put("clave3", "valor3");
        
        mapa2.forEach((k, v) -> System.out.println(k + ", " + v));
        System.out.println("Intercalado:");
        intercalarClaveValor(mapa2).forEach((k, v) -> System.out.println(k + ", " + v));
        //Ejercicio 3
        String[] cadenas = new String[] { "Hola", "Saludos", "Ok" };
        imprimirDadoLongitud(cadenas);
        
        //Ejercicio 4
        System.out.println("Palabras aleatorias:");
        imprimirAleatorio("src/main/java/com/mycompany/ut6_pd3/palabras1.txt", 5);
    }
    
    //Ejercicio 1
    public static void eliminarEntradasNull(Map mapa) {
        ArrayList<Integer> arr = new ArrayList(mapa.size());
        mapa.forEach( (k, v) -> { if(v == null && k != null) arr.add((int)k); } );  
        arr.forEach((k) -> { mapa.remove(k); });
    }
    
    //Ejercicio 2
    public static Map<String, String> intercalarClaveValor(Map<String, String> mapa) {
        Map<String, String> resMapa = new HashMap<>(mapa.size());
        mapa.forEach((k, v) -> resMapa.put(v, k));
        return resMapa;
    }

    //Ejercicio 3
    public static void imprimirDadoLongitud(String[] arrCadena) {
        TreeMap tree = new TreeMap();
        
        for(String s : arrCadena) {
            tree.put(s.length(), s);
        }
        
        tree.forEach((k,v) -> { System.out.println(v); });
    }

    //Ejercicio 4
    public static void imprimirAleatorio(String rutaArchivo, int numeroLineasImprimir) {
        String[] cadenas = ManejadorArchivosGenerico.leerArchivo(rutaArchivo);
        Map<Integer, String> map = new HashMap(cadenas.length);
        
        int cont = 0;
        for(String c : cadenas) {
            map.put(cont++, c);
        }

        for(int i=0; i < numeroLineasImprimir; i++) {
            System.out.println(map.get((int) (Math.random() * cont)));
        }
    }
}
