package com.mycompany.ut7_ta4_ej2;

import java.util.Collection;

public class PruebaGrafo {

    public static void main(String[] args) {
        TGrafoDirigido gd = (TGrafoDirigido) UtilGrafos.cargarGrafo("src/main/java/com/mycompany/ut7_ta4_ej2/aeropuertos_1.txt", "src/main/java/com/mycompany/ut7_ta4_ej2/conexiones_1.txt",
                false, TGrafoDirigido.class);

        Object[] etiquetasarray = gd.getEtiquetasOrdenado();

        Double[][] matriz = UtilGrafos.obtenerMatrizCostos(gd.getVertices());
        UtilGrafos.imprimirMatrizMejorado(matriz, gd.getVertices(), "Matriz");
        Double[][] mfloyd = gd.floyd();
        UtilGrafos.imprimirMatrizMejorado(mfloyd, gd.getVertices(), "Matriz luego de FLOYD");

        Collection<TVertice> recorrido = gd.bpf();
        // imprimir etiquetas del bpf de todo el grafo....
        Collection<TVertice> recorrido_Asuncion = gd.bpf("Asuncion");
        Collection<TVertice> recorrido_SanPablo = gd.bpf("San_Pablo");
        Collection<TVertice> recorrido_Curitiba = gd.bpf("Curitiba");
        Collection<TVertice> recorrido_Santos = gd.bpf("Santos");
        // imprimir etiquetas del bpf desde Asunción....

        System.out.println("Bpf de todo el grafo:");
        for (TVertice i : recorrido) {
            System.out.print(i.getEtiqueta() + " ");
        }
        System.out.println("");
        System.out.println("Bpf Asunción:");
        for (TVertice j : recorrido_Asuncion) {
            System.out.print(j.getEtiqueta() + " ");
        }

        System.out.println("");
        System.out.println("Bpf San Pablo:");
        for (TVertice j : recorrido_SanPablo) {
            System.out.print(j.getEtiqueta() + " ");
        }
        System.out.println("");
        System.out.println("Bpf Curitiba:");
        for (TVertice j : recorrido_Curitiba) {
            System.out.print(j.getEtiqueta() + " ");
        }
        System.out.println("");
        System.out.println("Bpf Santos:");
        for (TVertice j : recorrido_Santos) {
            System.out.print(j.getEtiqueta() + " ");
        }
    }
}
