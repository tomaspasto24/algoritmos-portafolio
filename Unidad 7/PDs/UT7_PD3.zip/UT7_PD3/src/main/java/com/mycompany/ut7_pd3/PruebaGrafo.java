package com.mycompany.ut7_pd3;

public class PruebaGrafo {

    public static void main(String[] args) {
        System.out.println("Ejercicio1:");

        TGrafoDirigido vueleSeguro = (TGrafoDirigido) UtilGrafos.cargarGrafo("src/main/java/com/mycompany/ut7_pd3/aeropuertos.txt", "src/main/java/com/mycompany/ut7_pd3/conexiones.txt", false, TGrafoDirigido.class);
        Double[][] floyd = vueleSeguro.floyd();
        UtilGrafos.imprimirMatrizMejorado(floyd, vueleSeguro.getVertices(), "Matriz Floyd");

        System.out.println("Ejercicio2:");
        TCaminos caminos = vueleSeguro.todosLosCaminos("Montevideo", "Curitiba");
        TCamino camino = caminos.caminoMenorCosto();
        caminos.imprimirCaminosConsola();

        System.out.println("Camino de menor costo: " + camino.imprimirEtiquetas());

        caminos = vueleSeguro.todosLosCaminos("Porto_Alegre", "Santos");
        camino = caminos.caminoMenorCosto();
        caminos.imprimirCaminosConsola();

        System.out.println("Camino de menor costo: " + camino.imprimirEtiquetas());
        
        System.out.println("Ejercicio 3");
        vueleSeguro.bpf("Montevideo");
    }
}
